if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SCORING_final]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[SCORING_final]
GO

CREATE TABLE [dbo].[SCORING_final] (
	[loanProgram] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[rptType] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[servicerNumber] [int] NULL ,
	[servicerName] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[FinalScore] [real] NULL ,
	[meanComponent] [real] NULL ,
	[stdComponent] [real] NULL ,
	[OveralSTd] [real] NULL ,
	[MinScore] [real] NULL ,
	[MaxScore] [real] NULL ,
	[numPools] [int] NULL ,
	[numLoans] [int] NULL ,
	[aveLoanSize] [float] NULL ,
	[bench] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

