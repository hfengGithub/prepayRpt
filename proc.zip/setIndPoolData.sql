--------------------------------------------------------------------------
-- Procedure: setIndPoolData
-- Usage: setIndPoolData @v_type, @n_year, @n_month , @n_servicerNumber, @n_rank
-- Parameters: 
--    v_type: indicating the report is for Chicago (C) or System (S)
--    n_year, n_month: indicating the Year, month regarded as current.
--    n_servicerNumber: PFI number for the new PFI in top 20 list or for AllOthers
--    n_rank: the rank of the new comer in the top 20 list.
-- Comment: Called by adjCurPoolData(), loading historical data for specific PFI into poolData.
--------------------------------------------------------------------------

ALTER PROCEDURE setIndPoolData
   @v_type                   CHAR, 
   @n_year                   SMALLINT, 
   @n_month                  SMALLINT, 
   @n_servicerNumber         INT, 
   @n_rank                   INT AS
DECLARE 
   @n_invSpan                REAL,
   @n_WACSpan                REAL,
   @n_yearInit               SMALLINT, 
   @n_origYear               SMALLINT,
   @n_adjYearMonth           INT
   PRINT 'setIndPoolData: started'

-- init values
   SET @n_yearInit=(SELECT  refValue FROM rptReference WHERE refCode='STARTYEAR')
   SET @n_WACSpan=(SELECT  refValue FROM rptReference WHERE refCode='WACSPAN')

   SET @n_adjYearMonth=100*@n_Year + @n_month
   SET @n_invSpan=ROUND(1/@n_WACSpan, 0)

   PRINT 'setIndPoolData: yearMonth.PFI: '+ CAST(@n_adjYearMonth AS VARCHAR)+'.'+CAST(@n_servicerNumber AS VARCHAR)
   IF @v_type='C'
      INSERT INTO reports.dbo.poolData (
         rptYear, rptMonth, origYear, origTerm, loanProgram, servicerNumber,
         WACLow,
         WAC,
         poolFactor,
         origBal,
         curBal ,
         prevBal ,
         SMM,
         WALA,
         adjYearMonth, rptType, numLoans, aveLoanSize, aveChgoPart, sumChgoPart)    
      SELECT 
         ah.HistYear, ah.histMonth, YEAR(m.origDate), m.origTerm, m.loanProgram, @n_servicerNumber,
         WACLow=-@n_WACSpan+CEILING(ROUND(@n_invSpan*ah.grossCoupon, 5))/@n_invSpan,
         WAC=SUM(ISNULL(ah.grossCoupon*ah.currentBal*cp.chicagoParticipation,0))/
            (SUM(ISNULL(ah.currentBal*cp.chicagoParticipation,0))+.0001), 
         poolFactor=SUM(ISNULL(ah.currentBal*cp.chicagoParticipation,0)) /
            (SUM(m.OrigBal*cp.chicagoParticipation)+.0001), 
         SUM(m.OrigBal*cp.chicagoParticipation),
         curBal=SUM(ISNULL(ah.currentBal*cp.chicagoParticipation,0)),
         prevBal=SUM(ISNULL(ah.PreviousBal*cp.chicagoParticipation,0)), 
         SMM=SUM(ISNULL(ah.PreviousBal*cp.chicagoParticipation*ah.SMM/100,0))/
            (SUM(ISNULL(ah.PreviousBal*cp.chicagoParticipation,0))+.00001),
         WALA=SUM(ISNULL(ah.WALA*ah.currentBal*cp.chicagoParticipation,0))/
                    (SUM(ISNULL(ah.currentBal*cp.chicagoParticipation,0))+.00001),
         @n_adjYearMonth, @v_type, COUNT(*), 
         aveLoanSize=SUM(ISNULL(ah.currentBal*ah.currentBal*cp.chicagoParticipation,0))/
            (SUM(ISNULL(ah.currentBal*cp.chicagoParticipation,0))+.00001),
         aveChgoPart=SUM(ISNULL(ah.currentBal*cp.chicagoParticipation,0))/
            (SUM(ISNULL(ah.currentBal,0))+.00001),
         sumChgoPart=SUM(ISNULL(cp.chicagoParticipation,0))                     
      FROM   servicerPool p, AFT.dbo.AFTMaster m, AFT.dbo.aftHistory ah, 
             aft_work.dbo.chicagoParticipation_loanLevel cp 
      WHERE  p.poolRank=@n_rank               
      AND    p.rptYear=@n_year
      AND    p.rptMonth=@n_month
      AND    p.rptType=@v_type
      AND    m.servicerNumber=p.servicerNumber               
      AND    m.OrigBal> 0
      AND    m.agency='FHLB'
      AND    m.origTerm>=180
      AND    Year(m.OrigDate) >= @n_yearInit
      AND    cp.loanNumber=m.loanIDnumber
      AND    cp.chicagoParticipation>0
      AND    (ah.HistYear<@n_year OR (ah.HistYear=@n_year AND ah.histMonth<@n_month) )
      AND    m.loanIDnumber=ah.loanIDnumber
      GROUP BY m.loanProgram, YEAR(m.origDate), m.origTerm, ah.HistYear, ah.histMonth, 
         -@n_WACSpan+CEILING(ROUND(@n_invSpan*ah.grossCoupon, 5))/@n_invSpan
   ELSE
      INSERT INTO reports.dbo.poolData (
         rptYear, rptMonth, origYear, origTerm, loanProgram, servicerNumber,
         WACLow,
         WAC,
         poolFactor,
         origBal,
         curBal ,
         prevBal ,
         SMM,
         WALA,
         adjYearMonth, rptType, numLoans, aveLoanSize)    
      SELECT 
         ah.HistYear, ah.histMonth, YEAR(m.origDate), m.origTerm, m.loanProgram, @n_servicerNumber,
         WACLow=-@n_WACSpan+CEILING(ROUND(@n_invSpan*ah.grossCoupon, 5))/@n_invSpan,
         WAC=SUM(ISNULL(ah.grossCoupon*ah.currentBal,0))/(SUM(ISNULL(ah.currentBal,0))+.0001), 
         poolFactor=SUM(ISNULL(ah.currentBal,0)) / (SUM(m.OrigBal)+.0001), 
         SUM(m.OrigBal),
         curBal=SUM(ISNULL(ah.currentBal,0)),
         prevBal=SUM(ISNULL(ah.PreviousBal,0)), 
         SMM=SUM(ISNULL(ah.PreviousBal*ah.SMM/100,0))/(SUM(ISNULL(ah.PreviousBal,0))+.00001),
         WALA=SUM(ISNULL(ah.WALA*ah.currentBal,0))/(SUM(ISNULL(ah.currentBal,0))+.00001),
         @n_adjYearMonth, @v_type, COUNT(*), SUM(ISNULL(ah.currentBal,0))/(COUNT(*)+0.00001)          
      FROM   servicerPool p, AFT.dbo.AFTMaster m, AFT.dbo.aftHistory ah
      WHERE  p.poolRank=@n_rank               
      AND    p.rptYear=@n_year
      AND    p.rptMonth=@n_month
      AND    p.rptType=@v_type
      AND    m.servicerNumber=p.servicerNumber               
      AND    m.OrigBal> 0
      AND    m.agency='FHLB'
      AND    m.origTerm>=180
      AND    Year(m.OrigDate) >= @n_yearInit
      AND    (ah.HistYear<@n_year OR (ah.HistYear=@n_year AND ah.histMonth<@n_month) )
      AND    m.loanIDnumber=ah.loanIDnumber
      GROUP BY m.loanProgram, YEAR(m.origDate), m.origTerm, ah.HistYear, ah.histMonth, 
         -@n_WACSpan+CEILING(ROUND(@n_invSpan*ah.grossCoupon, 5))/@n_invSpan

   PRINT 'setIndPoolData: ended'

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

