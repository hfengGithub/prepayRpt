---------------------------------------------------------------------------
-- rankCurServicer
-- Usage: rankCurServicer @v_type, @n_year, @n_month
-- Parameters: 
--    v_type: indicating the report is for Chicago (C) or System (S)
--    n_year, n_month: indicating the Year, month regarded as current.
-- Comment: Called by collectData(). For the current period, determine the top 20 PFIs and AllOthers 
--    according to their current balances and write their ranks into servicerPool.
---------------------------------------------------------------------------

ALTER PROCEDURE rankCurServicer 
   @v_type CHAR,
   @n_year SMALLINT=NULL, 
   @n_month SMALLINT=NULL
AS
   INSERT INTO etlLog (process, timeStamp,  message)
   VALUES ('rankCurServicer', getdate(), 'Started')

   DECLARE @n_servicerNumber INT, @n_curBal float
   DECLARE @n_rankOther SMALLINT, @n_rank SMALLINT, @n_top SMALLINT
      SET @n_rankOther=(SELECT refValue FROM rptReference WHERE refCode='RANKOTHER')
      SET @n_rank=(SELECT refValue FROM rptReference WHERE refCode='RANKFIRST')
      SET @n_top=(SELECT refValue FROM rptReference WHERE refCode='RANKLAST')

   IF (@n_year IS NULL)
   BEGIN
      SET @n_year=YEAR(getdate())
      SET @n_month=MONTH(getdate())
   END
   
   IF (@v_type='C')
      DECLARE c_servicer CURSOR FOR
         SELECT m.servicerNumber, SUM(p.chicagoParticipation*(CASE 
            WHEN m.curBal=0 THEN CASE WHEN m.curWAC=0 THEN m.origBal ELSE 0 END
            ELSE m.curBal END)) bal 
         FROM   aft_work.dbo.chicagoParticipation_loanLevel p, aft.dbo.aftMaster m 
         WHERE  p.loanNumber=m.loanIDnumber
         AND    m.agency='FHLB'
         GROUP BY m.servicerNumber
         ORDER BY bal DESC
   ELSE
      DECLARE c_servicer CURSOR FOR
         SELECT servicerNumber, SUM( CASE 
            WHEN curBal=0 THEN CASE WHEN curWAC=0 THEN origBal ELSE 0 END
            ELSE curBal END) bal
         FROM   aft.dbo.aftMaster
         WHERE  agency='FHLB'
         GROUP BY servicerNumber
         ORDER BY bal DESC

   INSERT INTO servicerPool (rptYear, rptMonth, poolRank, servicerNumber, rptType) 
   SELECT @n_year, @n_month, 1, servicerNumber, @v_type
   FROM   servicer
   WHERE  servicerName='MPF'
      
   INSERT INTO servicerPool (rptYear, rptMonth, poolRank, servicerNumber, rptType) 
   SELECT @n_year, @n_month, @n_rankOther, s.servicerNumber, @v_type
   FROM   servicer s
   WHERE  s.servicerName='All Others'

   OPEN c_servicer
   FETCH NEXT FROM c_servicer INTO @n_servicerNumber, @n_curBal
   
   WHILE (@@FETCH_STATUS <> -1)
   BEGIN
      INSERT INTO servicerPool (
         rptYear,
         rptMonth,
         poolRank,
         servicerNumber,
         curBal, 
         rptType) 
      VALUES (@n_year, @n_month, @n_rank, @n_servicerNumber, @n_curBal, @v_type)

      IF ( @n_rank<=@n_top ) 
         IF ( @n_rank<@n_top ) SET @n_rank = @n_rank + 1
         ELSE SET @n_rank = @n_rankOther 
      
      FETCH NEXT FROM c_servicer INTO @n_servicerNumber, @n_curBal
   END
   CLOSE c_servicer
   DEALLOCATE c_servicer

   INSERT INTO etlLog (process, timeStamp,  message)
   VALUES ('rankCurServicer', getdate(), 'Ended')

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

