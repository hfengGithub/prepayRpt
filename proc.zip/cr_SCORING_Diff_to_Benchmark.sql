if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SCORING_Diff_to_Benchmark]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[SCORING_Diff_to_Benchmark]
GO

CREATE TABLE [dbo].[SCORING_Diff_to_Benchmark] (
	[LoanProgram] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[OrigTerm] [smallint] NOT NULL ,
	[OrigYear] [smallint] NOT NULL ,
	[BENCHOrigYear] [smallint] NOT NULL ,
	[WACLow] [float] NOT NULL ,
	[ServicerNumber] [int] NULL ,
	[rptType] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[numLoans3MonBefore] [int] NULL ,
	[bal3MonBefore] [float] NULL ,
	[OrigBal] [float] NULL ,
	[CPR3moBench] [real] NULL ,
	[CPR3moServ] [real] NULL ,
	[CPR3moDifftoBench] [real] NULL ,
	[numLoans] [int] NULL ,
	[numLoansLag3Hat] [int] NOT NULL ,
	[SMM3moServ] [real] NULL ,
	[SMM3moBench] [real] NULL ,
	[CI01] [int] NOT NULL ,
	[CI05] [int] NOT NULL ,
	[CI10] [int] NOT NULL ,
	[CI20] [int] NOT NULL ,
	[CI40] [int] NOT NULL ,
	[CI60] [int] NOT NULL ,
	[CI80] [int] NOT NULL ,
	[CI90] [int] NOT NULL ,
	[CI95] [int] NOT NULL ,
	[CI99] [int] NOT NULL ,
	[poolFlag] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[poolScore] [int] NOT NULL ,
	[bench] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

