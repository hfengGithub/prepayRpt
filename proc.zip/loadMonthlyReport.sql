-----------------------------------------------------------------------
-- Procedure: loadMonthlyReport
-- Usage: loadMonthlyReport @v_type, @v_agencyData, @n_year, @n_month
-- Parameters: 
--    v_type: indicating the report is for Chicago (C) or System (S)
--    v_agencyData: indicating whether loading agency data or not (Y/N) 
--    n_year, n_month: indicating the Year, month regarded as current (default=current).
-- Comment: Called by collectData(), for the current period, load summary data from poolData 
--    into monthlyReport, and load agency data from aft_work..
-----------------------------------------------------------------------

ALTER PROC loadMonthlyReport 
   @v_type CHAR,
   @v_agencyData VARCHAR(1)='N',
   @n_year SMALLINT=NULL, 
   @n_month SMALLINT=NULL AS
DECLARE @d_3monBefore DATETIME
DECLARE @n_max INT, @n_adjYearMonth INT
   SET @n_max=(SELECT CAST(MAX(curBal)/10000 AS INT)+200 FROM poolData)
      
   IF (@n_year IS NULL)
   BEGIN
      SET @n_year=YEAR(getdate())
      SET @n_month=MONTH(getdate())
   END
   SET @n_adjYearMonth=100*@n_Year + @n_month
   SET @d_3monBefore= DATEADD(MONTH, -3, aft.dbo.fn_yearMonthDayToDate(@n_Year, @n_Month, 18))
   
   INSERT INTO monthlyReport (
      agency,
      ServicerNumber,
      ServicerName,
      OrigTerm,
      LoanProgram ,
      GrossCoupon,
      GrossCouponInt,
      OrigYear,
      FactorCalc,
      OrigBal,
      CurrentBal,
      WALA,
      CPR1Month,
      CPR3Month,
      CPR6Month,
      CPR12Month,
      CPRLife,
      showRank,
      rptType, numLoans, bal3MonBefore, numLoans3MonBefore, sumChgoPart)
   SELECT 
      'MPF',
      s.ServicerNumber,
      s.ServicerName,
      d.OrigTerm,
      d.LoanProgram ,
      d.WAC,
      d.WACLow,
      d.OrigYear,
      d.poolFactor,
      d.OrigBal/1000000,
      d.CurBal/1000000,
      ROUND(d.WALA, 0),
      100*d.CPR1Month,
      100*d.CPR3Month,
      100*d.CPR6Month,
      100*d.CPR1year,
      100*d.CPRLife,
      showRank=
      CASE 
         WHEN s.servicerName='MPF' THEN 1
         WHEN s.servicerName='All Others' THEN @n_max
         ELSE @n_max-CAST(d.curBal/10000 AS INT)-100
      END,
      @v_type, d.numLoans, pre.curBal/1000000, pre.numLoans, d.sumChgoPart
   FROM   servicer s, poolData d LEFT OUTER JOIN (
      SELECT * FROM poolData pd
      WHERE  rptYear=YEAR(@d_3monBefore)
      AND    rptMonth=MONTH(@d_3monBefore) 
      AND    adjYearMonth=(
         SELECT MAX(adjYearMonth) FROM poolData
         WHERE  origYear=pd.origYear
         AND    origTerm=pd.origTerm
         AND    loanProgram=pd.loanProgram
         AND    WACLow=pd.WACLow
         AND    servicerNumber=pd.servicerNumber
         AND    rptType=pd.rptType
         AND    rptYear=pd.rptYear
         AND    rptMonth=pd.rptMonth )) AS pre
   ON  pre.servicerNumber=d.servicerNumber
   AND pre.rptType=d.rptType
   AND pre.origYear=d.origYear
   AND pre.origTerm=d.origTerm
   AND pre.loanProgram=d.loanProgram
   AND pre.WACLow=d.WACLow 
   WHERE  d.rptYear=@n_year
   AND    d.rptMonth=@n_month 
   AND    d.servicerNumber=s.servicerNumber
   AND    d.adjYearMonth=@n_adjYearMonth  
   AND    d.rptType=@v_type

   -- Loading agency data
   IF @v_agencyData='Y' 
      INSERT INTO monthlyReport (
         agency,
         ServicerNumber,
         ServicerName,
         OrigTerm,
         LoanProgram ,
         GrossCoupon,
         GrossCouponInt,
         OrigYear,
         FactorCalc,
         OrigBal,
         CurrentBal,
         WALA,
         CPR1Month,
         CPR3Month,
         CPR6Month,
         CPR12Month,
         CPRLife,
         Source,
         showRank)
      SELECT 
         agency,
         s.ServicerNumber,
         s.ServicerName,
         OrigTerm,
         CASE x.agency WHEN 'GNMA II' THEN 'Government' ELSE 'Conventional' END,
         WAC,
         wacLow,
         OrigYear,
         Factor,
         OBal/1000000,
         CBal/1000000,
         age,
         CPR1Month=CASE WHEN age<1 THEN NULL ELSE CPR1 END,
         CPR3Month=CASE WHEN age<3 THEN NULL ELSE CPR3 END,
         CPR6Month=CASE WHEN age<6 THEN NULL ELSE CPR6 END,
         CPR1year=CASE WHEN age<12 THEN NULL ELSE CPR12 END,
         CPRLife,
         'CPRCDR',
         showRank=2
      FROM   servicer s, aft_work.dbo.cprcdr_byWAC x, rptReference r
      WHERE  agency NOT LIKE '%MPF%'   
      AND    x.agency=s.servicerName
      AND    r.refCode='WACSPAN'
      AND    ABS(x.WACRange-r.refValue)<.1
      AND    100*@n_year+@n_month-asOfdate in (1, 89)



