if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[poolData]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[poolData]
GO

CREATE TABLE [dbo].[poolData] (
	[rptYear] [smallint] NOT NULL ,
	[rptMonth] [smallint] NOT NULL ,
	[servicerNumber] [int] NOT NULL ,
	[origYear] [smallint] NOT NULL ,
	[origTerm] [smallint] NOT NULL ,
	[loanProgram] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[WACLow] [real] NOT NULL ,
	[WAC] [real] NOT NULL ,
	[poolFactor] [real] NULL ,
	[origBal] [float] NULL ,
	[prevBal] [float] NULL ,
	[curBal] [float] NULL ,
	[WALA] [real] NULL ,
	[SMM] [real] NULL ,
	[CPR1month] [real] NULL ,
	[CPR3Month] [real] NULL ,
	[CPR6Month] [real] NULL ,
	[CPR1Year] [real] NULL ,
	[CPRLife] [real] NULL ,
	[adjYearMonth] [int] NOT NULL ,
	[rptType] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[aveLoanSize] [float] NULL ,
	[numLoans] [int] NULL ,
	[aveChgoPart] [real] NULL ,
	[sumChgoPart] [real] NULL ,
	[FICO] [real] NULL ,
	[LTV] [real] NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[poolData] WITH NOCHECK ADD 
	CONSTRAINT [PK_poolData] PRIMARY KEY  CLUSTERED 
	(
		[rptYear],
		[rptMonth],
		[servicerNumber],
		[origYear],
		[origTerm],
		[loanProgram],
		[WACLow],
		[adjYearMonth],
		[rptType]
	)  ON [PRIMARY] 
GO

