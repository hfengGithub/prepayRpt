if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SCORING_summary_brk]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[SCORING_summary_brk]
GO

CREATE TABLE [dbo].[SCORING_summary_brk] (
	[loanProgram] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[origTerm] [smallint] NOT NULL ,
	[rptType] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[servicerNumber] [int] NULL ,
	[servicerName] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[FinalVGCPR3moDifftoBench] [float] NULL ,
	[FinalSTDCPR3moDifftoBench] [float] NULL ,
	[FinalScore] [float] NULL ,
	[bal3MonBefore] [float] NULL ,
	[OveralSTd] [float] NULL ,
	[Min] [float] NULL ,
	[Max] [float] NULL ,
	[TotalNumberPools] [int] NULL ,
	[numLoans] [int] NULL ,
	[bench] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

