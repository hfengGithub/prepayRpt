if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[rptReference]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[rptReference]
GO

CREATE TABLE [dbo].[rptReference] (
	[refCode] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[refDescription] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[refValue] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

INSERT INTO rptReference (refCode, refDescription, refValue)
VALUES ('STARTYEAR', 'Earliest origYear', 2000)

INSERT INTO rptReference (refCode, refDescription, refValue)
VALUES ('WACSPAN', 'Difference between highest & lowest WACs in 1 group', '0.49999')

INSERT INTO rptReference (refCode, refDescription, refValue)
VALUES ('RANKMPF', 'Rank for MPF', 1)
INSERT INTO rptReference (refCode, refDescription, refValue)
VALUES ('RANKFIRST', 'First rank for PFIs', 101)
INSERT INTO rptReference (refCode, refDescription, refValue)
VALUES ('RANKLAST', 'Last rank for PFIs', 120)
INSERT INTO rptReference (refCode, refDescription, refValue)
VALUES ('RANKOTHER', 'Rank for "All Others"', 201)
