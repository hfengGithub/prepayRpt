if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[t_poolData]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[t_poolData]
GO

CREATE TABLE [dbo].[t_poolData] (
	[rptYear] [smallint] NOT NULL ,
	[rptMonth] [smallint] NOT NULL ,
	[origYear] [smallint] NOT NULL ,
	[origTerm] [smallint] NOT NULL ,
	[loanProgram] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[servicerNumber] [int] NOT NULL ,
	[WACLow] [real] NOT NULL ,
	[SMM] [real] NULL ,
	[WALA] [real] NULL ,
	[adjYearMonth] [int] NOT NULL ,
	[rptType] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

