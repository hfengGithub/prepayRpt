--------------------------------------------------------------------------
-- setCurPoolData
-- Usage: setCurPoolData @v_type, @n_year, @n_month
-- Parameters: 
--    v_type: indicating the report is for Chicago (C) or System (S)
--    n_year, n_month: indicating the Year, month regarded as current (default=current).
-- Comment: Called by collectData(). For the current period, extract, transform and load summary data 
--    into corresponding cohorts in poolData for the top 20 PFIs, AllOthers and MPF.
--------------------------------------------------------------------------

ALTER PROCEDURE setCurPoolData 
   @v_type CHAR, 
   @n_year SMALLINT=NULL, 
   @n_month SMALLINT=NULL AS
DECLARE 
   @n_invSpan REAL,
   @n_WACSpan REAL,
   @n_yearInit SMALLINT, @n_origYear SMALLINT,
   @n_adjYearMonth INT

   INSERT INTO etlLog (process, timeStamp,  message)
   VALUES ('setCurPoolData', getdate(), 'Started')

-- init values
   SET @n_yearInit=(SELECT  refValue FROM rptReference WHERE refCode='STARTYEAR')
   SET @n_WACSpan=(SELECT  refValue FROM rptReference WHERE refCode='WACSPAN')
   SET @n_invSpan=ROUND(1/@n_WACSpan, 0)
   IF (@n_year IS NULL)
   BEGIN
      SET @n_year=YEAR(getdate())
      SET @n_month=MONTH(getdate())
   END
   SET @n_adjYearMonth=100*@n_Year + @n_month


   IF @v_type='C'
      INSERT INTO poolData (
         rptYear, rptMonth, origYear, origTerm, loanProgram, servicerNumber,
         WACLow,
         WAC,
         poolFactor,
         origBal,
         curBal ,
         prevBal ,
         SMM,
         WALA,
         adjYearMonth, rptType, numLoans, aveLoanSize, aveChgoPart, sumChgoPart)    
      SELECT 
         @n_year, @n_month, origYear, origTerm, loanProgram, servicerNumber,
         WACLow,
         WAC, 
         poolFactor, 
         origBal,
         curBal, 
         prevBal ,
         SMM,
         WALA,
         @n_adjYearMonth, @v_type, cnt, curBal/(chgoPart+.00001), curBal/(sysCurBal+.00001), chgoPart
      FROM   (
         SELECT 
            c.origYear, c.origTerm, c.loanProgram, p1.servicerNumber,
            WACLow=-@n_WACSpan+CEILING(ROUND(@n_invSpan*c.CurWAC, 5))/@n_invSpan,
            WAC=SUM(c.CurWAC*cp.chicagoParticipation*c.curBal)/(SUM(c.curBal*cp.chicagoParticipation)+.00001), 
            poolFactor=SUM(c.curBal*cp.chicagoParticipation)/(SUM(c.OrigBal*cp.chicagoParticipation)+.00001), 
            origBal=SUM(c.OrigBal*cp.chicagoParticipation),
            chgoPart=SUM(cp.chicagoParticipation*c.cnt1),
            curBal=SUM(c.curBal*cp.chicagoParticipation),
            sysCurBal=SUM(c.curBal),
            prevBal=SUM(c.prevBal*cp.chicagoParticipation), 
            SMM=SUM(c.prevBal*cp.chicagoParticipation*c.SMM)/(SUM(c.prevBal*cp.chicagoParticipation)+.00001),
            WALA=SUM(c.curWALA*c.curBal*cp.chicagoParticipation)/
               (SUM(c.curBal*cp.chicagoParticipation)+.00001),
            cnt=SUM(c.cnt1) 
         FROM   aft_work.dbo.chicagoParticipation_loanLevel cp, servicerPool p, servicerPool p1, (
            SELECT 
               a.loanIDnumber, origYear, origTerm, loanProgram, 
               -- New curWAC 12-19-2003
               CurWAC=100*fm.interestRate, 
               OrigBal, curWALA, 
               CurBal=ISNULL(b.CurrentBal,CASE WHEN a.curWAC=0 THEN a.origBal ELSE a.curBal END), 
               PrevBal=ISNULL(b.PreviousBal,0), 
               SMM=ISNULL(b.SMM/100,0), a.servicerNumber,
               cnt1=CASE WHEN (b.CurrentBal IS NOT NULL AND b.CurrentBal>0) OR 
                              (b.CurrentBal IS NULL AND a.curWAC=0) THEN 1 ELSE 0 END
            FROM   fhlb.dbo.fhlbMaster fm, (
               SELECT m.loanIDnumber, Year(m.OrigDate) origYear, m.origTerm, m.curBal,
                      m.loanProgram, m.CurWAC, m.OrigBal, m.curWALA, m.servicerNumber 
               FROM   AFT.dbo.AFTMaster m
               WHERE  m.OrigBal> 0
               AND    m.OrigTerm>=180 
               AND    Year(m.OrigDate) >= @n_yearInit
               AND    m.agency='FHLB'
               AND    MONTH(m.OrigDate)<=CASE WHEN (YEAR(m.OrigDate)=@n_year) THEN @n_month ELSE 12 END
            ) AS A LEFT OUTER JOIN (
               SELECT loanIDnumber, CurrentBal, PreviousBal, smm
               FROM   AFT.dbo.aftHistory ah
               WHERE  ah.HistYear=@n_year
               AND    ah.histMonth=@n_month
            ) AS B ON a.loanIDnumber=b.loanIDnumber
            WHERE    A.loanIDnumber=fm.loanNumber
         ) AS C
         WHERE  p.rptYear=@n_year
         AND    p.rptMonth=@n_month
         AND    p.rptType=@v_type
         AND    p1.rptYear=@n_year
         AND    p1.rptMonth=@n_month
         AND    p1.poolRank=p.poolRank
         AND    p1.rptType=@v_type
         AND    p1.servicerNumber=(
            SELECT MIN(servicerNumber) FROM servicerPool 
            WHERE  rptYear=@n_year AND rptMonth=@n_month 
            AND    rptType=@v_type
            AND    poolRank=p1.poolRank)
         AND    p.servicerNumber=c.servicerNumber               
         AND    c.loanIDnumber=cp.loanNumber
         AND    cp.chicagoParticipation>0
         GROUP BY c.loanProgram, c.origYear, c.origTerm, p1.servicerNumber, 
            -@n_WACSpan+CEILING(ROUND(@n_invSpan*c.CurWAC, 5))/@n_invSpan
      ) AS T
   ELSE
      INSERT INTO poolData (
         rptYear, rptMonth, origYear, origTerm, loanProgram, servicerNumber,
         WACLow,
         WAC,
         poolFactor,
         origBal,
         curBal ,
         prevBal ,
         SMM,
         WALA,
         adjYearMonth, rptType, numLoans, aveLoanSize)    
      SELECT 
         @n_year, @n_month, origYear, origTerm, loanProgram, servicerNumber,
         WACLow,
         WAC, 
         poolFactor, 
         origBal,
         curBal, 
         prevBal ,
         SMM,
         WALA,
         @n_adjYearMonth, @v_type, cnt, curBal/(cnt+.00001)
      FROM   (
         SELECT 
            a.origYear, a.origTerm, a.loanProgram, a.servicerNumber,
            WACLow=-@n_WACSpan+CEILING(ROUND(@n_invSpan*100*fm.interestRate, 5))/@n_invSpan,
            WAC=SUM(100*fm.interestRate*ISNULL(b.CurrentBal,CASE WHEN a.curWAC=0 THEN a.origBal ELSE a.curBal END))/
               (SUM(ISNULL(b.CurrentBal,CASE WHEN a.curWAC=0 THEN a.origBal ELSE a.curBal END))+.00001), 
            poolFactor=SUM(ISNULL(b.CurrentBal,CASE WHEN a.curWAC=0 THEN a.origBal ELSE a.curBal END))/
               (SUM(a.OrigBal)+.00001), 
            origBal=SUM(a.OrigBal),
            curBal=SUM(ISNULL(b.CurrentBal,CASE WHEN a.curWAC=0 THEN a.origBal ELSE a.curBal END)),
            prevBal=SUM(ISNULL(b.PreviousBal,0)), 
            SMM=SUM(ISNULL(b.PreviousBal,0)*ISNULL(b.SMM/100,0))/
               (SUM(ISNULL(b.PreviousBal,0))+.000001),
            WALA=SUM(a.curWALA*ISNULL(b.CurrentBal,CASE WHEN a.curWAC=0 THEN a.origBal ELSE a.curBal END))/
               (SUM(ISNULL(b.CurrentBal,CASE WHEN a.curWAC=0 THEN a.origBal ELSE a.curBal END))+.000001),
            cnt=SUM(SIGN(ISNULL(b.CurrentBal,CASE WHEN a.curWAC=0 THEN a.origBal ELSE a.curBal END)) )
         FROM    fhlb.dbo.fhlbMaster fm, (
            SELECT m.loanIDnumber, p1.servicerNumber, Year(m.OrigDate) origYear, m.origTerm, 
                   m.loanProgram, m.CurWAC, m.OrigBal, m.curBal, m.curWALA 
            FROM   servicerPool p, servicerPool p1, AFT.dbo.AFTMaster m
            WHERE  p.rptYear=@n_year
            AND    p.rptMonth=@n_month
            AND    p.rptType=@v_type
            AND    p1.rptYear=@n_year
            AND    p1.rptMonth=@n_month
            AND    p1.poolRank=p.poolRank
            AND    p1.rptType=@v_type
            AND    p1.servicerNumber=(
               SELECT MIN(servicerNumber) FROM servicerPool 
               WHERE  rptYear=@n_year AND rptMonth=@n_month 
               AND    rptType=@v_type
               AND    poolRank=p1.poolRank)
            AND    p.servicerNumber=m.servicerNumber               
            AND    m.OrigBal> 0
            AND    m.OrigTerm>=180 
            AND    Year(m.OrigDate) >= @n_yearInit
            AND    m.agency='FHLB'
            AND    MONTH(m.OrigDate)<=CASE WHEN (@n_origYear=@n_year) THEN @n_month ELSE 12 END
         ) AS A LEFT OUTER JOIN (
            SELECT loanIDnumber, CurrentBal, PreviousBal, smm
            FROM   AFT.dbo.aftHistory ah
            WHERE  ah.HistYear=@n_year
            AND    ah.histMonth=@n_month
         ) AS B ON a.loanIDnumber=b.loanIDnumber
         WHERE    A.loanIDnumber=fm.loanNumber
         GROUP BY a.loanProgram, a.origYear, a.origTerm, a.servicerNumber, 
            -@n_WACSpan+CEILING(ROUND(@n_invSpan*100*fm.interestRate, 5))/@n_invSpan
      ) AS T

   IF @@ERROR<>0
   BEGIN
      INSERT INTO etlLog (process, timeStamp,  message)
      VALUES ('setCurPoolData', getdate(), 'Fail to insert into poolData')
      PRINT 'setCurPoolData: Fail to insert into poolData'
      RETURN 1
   END
         
   -- Create MPF records
   INSERT INTO poolData (
      rptYear ,
      rptMonth ,
      origYear,
      origTerm,
      loanProgram,
      servicerNumber,
      WACLow,
      WAC,
      poolFactor,
      origBal,
      curBal ,
      prevBal ,
      SMM,
      WALA,
      adjYearMonth, rptType, numLoans, 
      aveLoanSize, 
      aveChgoPart,
      sumChgoPart)    
   SELECT  
      @n_Year ,
      @n_Month ,
      origYear,
      origTerm,
      loanProgram,
      servicerNumber,
      WACLow,
      WAC, 
      factor, 
      OrigBal,
      curBal,
      prevBal, 
      SMM,
      WALA,
      @n_adjYearMonth, @v_type, cnt, 
      aveLoanSize=CASE WHEN @v_type='C' THEN curBal/(chgoPart+(1-SIGN(chgoPart))*.00001) ELSE curBal/(cnt+.00001) END, 
      curBal/(sysCurBal+.00001), 
      chgoPart
   FROM   (
      SELECT  
         origYear,
         origTerm,
         loanProgram,
         s.servicerNumber,
         WACLow,
         WAC=SUM(WAC*CurBal)/(SUM(CurBal)+.00001), 
         factor=SUM(CurBal) /SUM(OrigBal), 
         origBal=SUM(OrigBal),
         sysCurBal=SUM(curBal/(aveChgoPart+(1-SIGN(aveChgoPart))*.000001)),
         curBal=SUM(CurBal),
         prevBal=SUM(PrevBal), 
         SMM=SUM(PrevBal*SMM)/(SUM(PrevBal)+.000001),
         WALA=ROUND(SUM(WALA*CurBal)/(SUM(CurBal)+.00001), 0),
         cnt=SUM(numLoans), 
         chgoPart=SUM(sumChgoPart)
      FROM   poolData p, servicer s
      WHERE  p.rptYear=@n_Year
      AND    p.rptMonth=@n_Month
      AND    p.rptType=@v_type
      AND    s.servicerName='MPF'
      GROUP BY p.origYear, p.origTerm, p.loanProgram, p.WACLow, s.servicerNumber
   ) AS T

   IF @@ERROR<>0
   BEGIN
      INSERT INTO etlLog (process, timeStamp,  message)
      VALUES ('setCurPoolData', getdate(), 'Fail to create MPF records')
      PRINT 'setCurPoolData: Fail to create MPF records'
      RETURN 1
   END

   INSERT INTO etlLog (process, timeStamp,  message)
   VALUES ('setCurPoolData', getdate(), 'Ended')
         
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
