if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[t_servicerPoolHist]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[t_servicerPoolHist]
GO

CREATE TABLE [dbo].[t_servicerPoolHist] (
	[rptYear] [smallint] NOT NULL ,
	[rptMonth] [smallint] NOT NULL ,
	[poolRank] [smallint] NOT NULL ,
	[servicerNumber] [int] NOT NULL ,
	[curBal] [float] NULL ,
	[rptType] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[runPeriod] [int] NULL 
) ON [PRIMARY]
GO

