CREATE TABLE etlLog (
   process              VARCHAR(30) NOT NULL,
   timeStamp            DATETIME,
   message              VARCHAR(200))
   