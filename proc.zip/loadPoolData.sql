-----------------------------------------------------------------------
-- loadPoolData
-- Usage: loadPoolData @v_type, @n_year, @n_month
-- Parameters: 
--    v_type: indicating the report is for Chicago (C) or System (S)
--    n_year, n_month: indicating the Year, month regarded as current.
-- Comment: Called by collectData(). For periods prior to the current one, extract, transform and 
--    load summary data into corresponding cohorts in poolData for the top 20 PFIs, AllOthers and MPF.
-----------------------------------------------------------------------

ALTER PROCEDURE loadPoolData(@v_type CHAR, @n_year SMALLINT, @n_month SMALLINT) AS
DECLARE 
   @n_invSpan REAL,
   @n_WACSpan REAL,
   @n_yearInit SMALLINT, @n_origYear SMALLINT,
   @n_adjYearMonth INT

   INSERT INTO etlLog (process, timeStamp,  message)
   VALUES ('loadPoolData', getdate(), 'Started')

-- init values
   SET @n_yearInit=(SELECT  refValue FROM rptReference WHERE refCode='STARTYEAR')
   SET @n_WACSpan=(SELECT  refValue FROM rptReference WHERE refCode='WACSPAN')

   SET @n_adjYearMonth=100*@n_Year + @n_month
   SET @n_invSpan=ROUND(1/@n_WACSpan, 0)

   
   IF @v_type='C'
      INSERT INTO poolData (
         rptYear, rptMonth, origYear, origTerm, loanProgram, servicerNumber,
         WACLow,
         WAC,
         poolFactor,
         origBal,
         curBal ,
         prevBal ,
         SMM,
         WALA,
         adjYearMonth, rptType, numLoans, aveLoanSize, aveChgoPart, sumChgoPart)    
      SELECT 
         HistYear, histMonth, OY, origTerm, loanProgram, servicerNumber,
         WACLow,
         WAC=wGC/(curBal+.00001), 
         poolFactor=curBal/(origBal+.00001), 
         origBal,
         curBal,
         prevBal, 
         SMM=wSMM/(prevBal+.000001),
         WALA=wWALA/(curBal+.000001),
         adjYearMonth, @v_type, cnt, curBal/(chgoPart+.00001), curBal/(sysCurBal+.00001), chgoPart           
      FROM   (
         SELECT 
            ah.HistYear, ah.histMonth, OY=YEAR(m.origDate), m.origTerm, m.loanProgram, p1.servicerNumber,
            WACLow=-@n_WACSpan+CEILING(ROUND(@n_invSpan*ah.grossCoupon, 5))/@n_invSpan,
            wGC=SUM(ISNULL(ah.grossCoupon*ah.currentBal*cp.chicagoParticipation,0)),
            origBal=SUM(m.OrigBal*cp.chicagoParticipation),
            curBal=SUM(ISNULL(ah.currentBal*cp.chicagoParticipation,0)),
            prevBal=SUM(ISNULL(ah.PreviousBal*cp.chicagoParticipation,0)), 
            chgoPart=SUM(cp.chicagoParticipation),                       -- curLoanSize(sys)=curBal
            wSMM=SUM(ISNULL(ah.PreviousBal*cp.chicagoParticipation*ah.SMM/100,0)),
            wWALA=SUM(ISNULL(ah.WALA*ah.currentBal*cp.chicagoParticipation,0)),
            sysCurBal=SUM(ISNULL(ah.currentBal,0)),
            adjYearMonth=100*ah.HistYear+ah.histMonth,
            cnt=COUNT(*)        
         FROM   servicerPool p, servicerPool p1, AFT.dbo.AFTMaster m, AFT.dbo.aftHistory ah, 
                aft_work.dbo.chicagoParticipation_loanLevel cp 
         WHERE  m.OrigBal> 0
         AND    m.origTerm>=180
         AND    Year(m.OrigDate) >= @n_yearInit
         AND    m.agency='FHLB'
         AND    m.loanIDnumber=ah.loanIDnumber
         AND    (ah.HistYear<@n_year OR (ah.HistYear=@n_year AND ah.histMonth<=@n_month) )
         AND    p.servicerNumber=m.servicerNumber               
         AND    p.rptYear=ah.HistYear
         AND    p.rptMonth=ah.histMonth
         AND    p.rptType=@v_type
         AND    p1.rptYear=ah.histYear
         AND    p1.rptMonth=ah.histMonth
         AND    p1.rptType=@v_type
         AND    p1.poolRank=p.poolRank
         AND    p1.servicerNumber=(
            SELECT MIN(servicerNumber) FROM servicerPool 
            WHERE  rptYear=ah.histYear AND rptMonth=ah.histMonth 
            AND    rptType=@v_type
            AND    poolRank=p1.poolRank)
         AND    cp.loanNumber=m.loanIDnumber
         AND    cp.chicagoParticipation>0
         GROUP BY m.loanProgram, YEAR(m.origDate), m.origTerm, ah.HistYear, ah.histMonth, 
            -@n_WACSpan+CEILING(ROUND(@n_invSpan*ah.grossCoupon, 5))/@n_invSpan, p1.servicerNumber
      ) AS T
   ELSE
      INSERT INTO poolData (
         rptYear, rptMonth, origYear, origTerm, loanProgram, servicerNumber,
         WACLow,
         WAC,
         poolFactor,
         origBal,
         curBal ,
         prevBal ,
         SMM,
         WALA,
         adjYearMonth, rptType, numLoans, aveLoanSize)    
      SELECT 
         HistYear, histMonth, OY, origTerm, loanProgram, servicerNumber,
         WACLow,
         WAC=wGC/(curBal+.00001), 
         poolFactor=curBal/(origBal+.00001), 
         origBal,
         curBal,
         prevBal, 
         SMM=wSMM/(prevBal+.000001),
         WALA=wWALA/(curBal+.000001),
         adjYearMonth, @v_type, cnt, curBal/cnt           
      FROM   (
         SELECT 
            ah.HistYear, ah.histMonth, OY=YEAR(m.origDate), m.origTerm, m.loanProgram, p1.servicerNumber,
            WACLow=-@n_WACSpan+CEILING(ROUND(@n_invSpan*ah.grossCoupon, 5))/@n_invSpan,
            wGC=SUM(ISNULL(ah.grossCoupon*ah.currentBal,0)),
            origBal=SUM(m.OrigBal),
            curBal=SUM(ISNULL(ah.currentBal,0)),
            prevBal=SUM(ISNULL(ah.PreviousBal,0)), 
            wSMM=SUM(ISNULL(ah.PreviousBal*ah.SMM/100,0)),
            wWALA=SUM(ISNULL(ah.WALA*ah.currentBal,0)),
            sysCurBal=SUM(ISNULL(ah.currentBal,0)),
            adjYearMonth=100*ah.HistYear+ah.histMonth,
            cnt=COUNT(*)        
         FROM   servicerPool p, servicerPool p1, AFT.dbo.AFTMaster m, AFT.dbo.aftHistory ah
         WHERE  m.OrigBal> 0
         AND    m.origTerm>=180
         AND    Year(m.OrigDate) >= @n_yearInit
         AND    m.agency='FHLB'
         AND    m.loanIDnumber=ah.loanIDnumber
         AND    (ah.HistYear<@n_year OR (ah.HistYear=@n_year AND ah.histMonth<=@n_month) )
         AND    p.servicerNumber=m.servicerNumber               
         AND    p.rptYear=ah.HistYear
         AND    p.rptMonth=ah.histMonth
         AND    p.rptType=@v_type
         AND    p1.rptYear=ah.histYear
         AND    p1.rptMonth=ah.histMonth
         AND    p1.rptType=@v_type
         AND    p1.poolRank=p.poolRank
         AND    p1.servicerNumber=(
            SELECT MIN(servicerNumber) FROM servicerPool 
            WHERE  rptYear=ah.histYear AND rptMonth=ah.histMonth 
            AND    rptType=@v_type
            AND    poolRank=p1.poolRank)
         GROUP BY m.loanProgram, YEAR(m.origDate), m.origTerm, ah.HistYear, ah.histMonth, 
            -@n_WACSpan+CEILING(ROUND(@n_invSpan*ah.grossCoupon, 5))/@n_invSpan, p1.servicerNumber
      ) AS T

   -- Create MPF records
   INSERT INTO poolData (
      rptYear, rptMonth, origYear, origTerm, loanProgram, servicerNumber,
      WACLow, WAC, poolFactor, origBal, curBal, prevBal, SMM, WALA,
      adjYearMonth, rptType, numLoans, aveLoanSize, aveChgoPart, sumChgoPart)    
   SELECT  
      rptYear, rptMonth, origYear, origTerm, loanProgram, servicerNumber,
      WACLow, WAC, poolFactor, origBal, curBal, prevBal, SMM, WALA,
      100*rptYear+rptMonth, @v_type, cnt, 
      aveLoanSize=CASE WHEN @v_type='C' THEN curBal/(chgoPart+.00001) ELSE curBal/cnt END, 
      curBal/(sysCurBal+.00001), chgoPart
   FROM   (
      SELECT  
         p.rptYear, p.rptMonth, origYear, origTerm, loanProgram, s.servicerNumber,
         WACLow,
         WAC=SUM(WAC*CurBal)/(SUM(CurBal)+.00001), 
         poolFactor=SUM(CurBal)/SUM(OrigBal), 
         origBal=SUM(OrigBal),
         wBal=SUM(curBal*aveLoanSize),
         sysCurBal=SUM(curBal/(aveChgoPart+(1-SIGN(aveChgoPart))*.000001)),
         curBal=SUM(CurBal),
         prevBal=SUM(PrevBal), 
         SMM=SUM(PrevBal*SMM)/(SUM(PrevBal)+.000001),
         WALA=ROUND(SUM(WALA*CurBal)/(SUM(CurBal)+.00001), 0),
         cnt=SUM(numLoans),
         chgoPart=SUM(sumChgoPart)
      FROM   poolData p, servicer s
      WHERE  (p.rptYear<@n_year OR (p.rptYear=@n_year AND p.rptMonth<=@n_month) )
      AND    p.rptType=@v_type
      AND    s.servicerName='MPF'
      GROUP BY p.origYear, p.origTerm, p.loanProgram, p.WACLow, p.rptYear, p.rptMonth, s.servicerNumber
   ) AS T

   IF @@ERROR<>0
   BEGIN
      INSERT INTO etlLog (process, timeStamp,  message)
      VALUES ('loadPoolData', getdate(), 'Fail to create MPF records')
      PRINT 'loadPoolData: Fail to create MPF records'
      RETURN 1
   END

   INSERT INTO etlLog (process, timeStamp,  message)
   VALUES ('loadPoolData', getdate(), 'Ended')

