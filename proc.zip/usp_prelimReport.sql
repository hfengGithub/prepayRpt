-----------------------------------------------------------------------
-- Procedure: usp_prelimReport 
-- Usage: usp_prelimReport @n_year, @n_month
-- Parameters: 
--    n_year, n_month: regarded the year, month as current period (default=current).
-- Comment: stand-alone procedure, trying to estimate CPR1 and current balance for last 
--    period of each MPF's cohort based on last period agency's data and the relationship 
--    between historical MPF's prepayment speed and those of agencies.
-----------------------------------------------------------------------

ALTER  PROC usp_prelimReport (
   @n_year SMALLINT=NULL, 
   @n_month SMALLINT=NULL )
AS 
   DECLARE @n_WACSpan real, @n_invSpan real
-- SET @n_invSpan=4
   SET @n_WACSpan=(SELECT  refValue FROM rptReference WHERE refCode='WACSPAN')
   SET @n_invSpan=ROUND(1/@n_WACSpan, 0)
   DECLARE @d_curDate DATETIME
   SET @d_curDate=getDate()
   
   IF (@n_year IS NULL)
   BEGIN
      SET @n_year=YEAR(@d_curDate)
      SET @n_month=MONTH(@d_curDate)
   END
   
   DECLARE @n_MPF INT, @n_FNMA INT, @n_FHLMC INT, @n_GNMA2 INT
   SELECT @n_MPF=s1.servicerNumber, @n_FNMA=s2.servicerNumber, 
          @n_FHLMC=s3.servicerNumber, @n_GNMA2=s4.servicerNumber
   FROM   servicer s1, servicer s2, servicer s3, servicer s4
   WHERE  s1.servicerName='MPF'
   AND    s2.servicerName='FNMA'
   AND    s3.servicerName='FHLMC'
   AND    s4.servicerName='GNMA II'
   
   -- insert MPF AND agency records
   INSERT INTO rpt_prelimReport (
      servicerNumber,
      ServicerName,
      OrigTerm,
      LoanProgram ,
      OrigYear ,
      WAClow,
      GrossCoupon,
      CPR1,
      estCPR1,
      estCurBal,
      curBal,
      preBal,
      WALA,
      CPR1Month ,
      CPR3Month ,
      CPR6Month,
      rptYearMonth)
   SELECT
      servicerNumber,
      p.ServicerName,
      p.OrigTerm,
      p.LoanProgram,
      p.OrigYear,
      WAClow=p.GrossCouponInt,
      p.GrossCoupon,
      c.CPR1,
      estCPR1=NULL,
      estCurBal=NULL,
      curBal=c.cBal/1000000,
      preBal=p.CurrentBal,
      WALA=ISNULL(c.age, p.WALA+1),
      CPR1Month,
      CPR3Month,
      CPR6Month,
      100*@n_Year+@n_Month
   FROM   monthlyReport AS p LEFT OUTER JOIN (
      SELECT * FROM aft_work.dbo.CPRCDR_byWAC 
      WHERE  origYear>1999 
      and    WACrange=1.0/@n_invSpan
      and    100*@n_Year+@n_Month-asOfDate in (1, 89)) AS c
   ON     p.servicerName=c.agency
   AND    p.origTerm=c.origTerm
   AND    p.origYear=c.origYear
   AND    p.GrossCouponInt=c.WACLow
   WHERE  p.servicerNUmber in (@n_MPF, @n_FNMA, @n_FHLMC, @n_GNMA2)
   AND    p.CurrentBal>0
   AND    p.origYear>1999
   AND    (p.rptType='C' OR p.rptType IS NULL)
   
   -- Calclating the estCPR1 for MPF
   UPDATE tar
   SET    estCPR1=
      CASE FLOOR(tar.CPR1month*C.CPR1/(100*(C.CPR1p1+.00001))) 
      WHEN 0 THEN tar.CPR1month*C.CPR1/(C.CPR1p1+.00001) 
      ELSE 100 END
   --   CASE ISNULL(CPR3month,-1) 
   --   WHEN CPR3month THEN 
   --      CASE FLOOR(tar.CPR3month*C.CPR1/(100*(C.CPR3+.00001))) WHEN 0 THEN tar.CPR3month*C.CPR1/(C.CPR3+.00001) ELSE 100 END
   --   ELSE 
   --      CASE FLOOR(tar.CPR1month*C.CPR1/(100*(C.CPR1p1+.00001))) WHEN 0 THEN tar.CPR1month*C.CPR1/(C.CPR1p1+.00001) ELSE 100 END
   --   END
   FROM   rpt_prelimReport AS tar, (
      SELECT 
         loanProgram=loanProgram,
         origTerm=origTerm,
         origYear=origYear,
         WACLow=WACLow,
         Cpr1=SUM(preBal*CPR1)/(SUM(preBal)+.000001),
         Cpr1p1=SUM(preBal*CPR1month)/(SUM(preBal)+.000001),
         Cpr3=SUM(preBal*CPR3Month)/(SUM(preBal)+.000001)
      FROM   rpt_prelimReport
      WHERE  servicerNumber<>@n_MPF
      GROUP BY loanProgram, origTerm, origYear, WACLow) AS C
   WHERE  tar.servicerNumber=@n_MPF
   AND    tar.loanProgram=c.loanProgram
   AND    tar.origTerm=c.origTerm
   AND    tar.origYear=c.origYear
   AND    tar.WACLow=c.WACLow
   AND    tar.rptYearMonth=100*@n_Year+@n_Month
   
   -- calculate the schedulePrincipal
   UPDATE rpt_prelimReport
   set    schPrincipal=w.schPrin/1000000
   from   rpt_prelimReport r, (
      select m.loanProgram, m.origTerm, YEAR(m.origDate) origYear, 
         -@n_WACSpan+CEILING(ROUND(@n_invSpan*m.curWAC, 5))/@n_invSpan as WAClow,
         SUM((v.mPay-v.curBal*m.curWAC/1200)*cp.chicagoParticipation) as schPrin
      from   aft.dbo.aftMaster m, aft_work.dbo.chicagoParticipation_loanLevel cp, (
         SELECT LoanNumber, CurrentSchedulePrincipal + CurrentScheduleInterest AS mPay, scheduleEndPrincipalBal curBal
         FROM   fhlb.dbo.FHLBHistory
         WHERE  DATEDIFF(MONTH, PayDate, @d_curDate)=1 ) as v
      where  m.loanIDnumber=v.loanNumber
      and    m.loanIDnumber=cp.loanNumber 
      GROUP BY m.loanProgram, m.origTerm, YEAR(m.origDate), 
         -@n_WACSpan+CEILING(ROUND(@n_invSpan*m.curWAC, 5))/@n_invSpan ) as w
   WHERE  r.servicerNumber=@n_MPF
   AND    r.loanProgram=w.loanProgram
   AND    r.origTerm=w.origTerm
   AND    r.origYear=w.origYear
   AND    r.WACLow=w.WACLow
   AND    r.rptYearMonth=100*@n_Year+@n_Month
   
   -- UPDATE rpt_prelimReport
   -- set    schPrincipal=v.schPrin/1000000
   -- from   rpt_prelimReport r, (
   --    select m.loanProgram, m.origTerm, YEAR(m.origDate) origYear, 
   --       -@n_WACSpan+CEILING(ROUND(@n_invSpan*fm.interestRate*100, 5))/@n_invSpan as WAClow,
   --       SUM((m.origBal*(fm.interestRate/12)/(1-power(1/(1+fm.interestRate/12),m.origTerm))-
   --          (CASE m.curBal WHEN 0 THEN (CASE m.curWAC WHEN 0 THEN m.origBal ELSE 0 END) ELSE m.curBal END)*fm.interestRate/12)*
   --          cp.chicagoParticipation) as schPrin
   --    from   aft.dbo.aftMaster m, aft_work.dbo.chicagoParticipation_loanLevel cp, fhlb.dbo.fhlbMaster fm
   --    where  m.loanIDnumber=cp.loanNumber 
   --    AND    m.loanIDnumber=fm.loanNumber 
   --    AND    m.agency='FHLB'
   --    AND    m.OrigBal> 0
   --    AND    m.OrigTerm>=180 
   --    GROUP BY m.loanProgram, m.origTerm, YEAR(m.origDate), 
   --       -@n_WACSpan+CEILING(ROUND(@n_invSpan*fm.interestRate*100, 5))/@n_invSpan ) as v
   -- WHERE  r.servicerNumber=@n_MPF
   -- AND    r.loanProgram=v.loanProgram
   -- AND    r.origTerm=v.origTerm
   -- AND    r.origYear=v.origYear
   -- AND    r.WACLow=v.WACLow
   -- AND    r.rptYearMonth=100*@n_Year+@n_Month
   
   -- Calclating the estCurBal for MPF
   UPDATE rpt_prelimReport
   SET    estCurBal=(preBal-SchPrincipal)*POWER(1-estCPR1/100, 1.0/12)
   WHERE  servicerNUmber=@n_MPF
   AND    rptYearMonth=100*@n_Year+@n_Month
   
   update rpt_prelimReport 
   set    chgBal=
      CASE servicerNumber WHEN 1000 THEN estCurBal-preBal
      ELSE curBal-preBal
      END
   where  rptYearMonth=100*@n_Year+@n_Month


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
