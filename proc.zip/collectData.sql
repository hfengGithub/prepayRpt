------------------------------------------------------------------
-- Procedure : collectData
-- Usage     : collectData @v_type, @v_agencyData, @n_year, @n_month
-- Parameters: 
--   v_type: indicating the report is for Chicago (C), System (S) or all (A)
--   v_agencyData: indicating whether loading agency data or not (Y/N, N=default) 
--   n_year, n_month: indicating the Year, month regarded as current (default=current).
-- Comment   : Called by loadAll(), Extracting, transforming and loading data into the servicerPool, 
--             poolData and monthlyReport tables by Calling, in the following order, the procedures: 
--             rankServicer(), rankCurServicer(), loadPoolData(), setCurPoolData(), adjPoolData(), 
--             setCPRlife(), setCPR and loadMonthlyReport(). 
------------------------------------------------------------------

ALTER PROC collectData
   @v_type CHAR, 
   @v_agencyData VARCHAR(1),
   @n_year SMALLINT, 
   @n_month SMALLINT AS
DECLARE @n_status INT, @n_SNumOther INT, @n_SNumMPF INT, @n_top SMALLINT
DECLARE @n_rptYear SMALLINT, @n_rptMonth SMALLINT
DECLARE @d_rptDate DATETIME, @d_curDate DATETIME
   SET @d_rptDate= '01/18/2000'
   SET @d_curDate=aft.dbo.fn_yearMonthDayToDate(@n_Year, @n_Month, 18)
   INSERT INTO etlLog (process, timeStamp,  message)
   VALUES ('reload', getdate(), 'Started')

   -- Set ranks for PFI's
   WHILE DATEDIFF(MONTH, @d_rptDate, @d_curDate) >= 1
   BEGIN
      set @n_rptYear=YEAR(@d_rptDate)
      set @n_rptMonth=MONTH(@d_rptDate)   
      EXEC @n_status=rankServicer @v_type, @n_rptYear, @n_rptMonth
      IF @n_status<>0
      BEGIN
         PRINT 'reload: Fail to call rankServicer'
         RETURN 1
      END
      SET @d_rptDate=DATEADD(MONTH, 1, @d_rptDate)
   END
   EXEC rankCurServicer @v_type, @n_year, @n_month

   SET @n_SNumMPF=(SELECT servicerNumber FROM servicer WHERE servicerName='MPF')
   SET @n_SNumOther=(SELECT servicerNumber FROM servicer WHERE servicerName='All Others')
   SET @n_top=(SELECT refValue FROM rptReference WHERE refCode='RANKLAST')
   
   UPDATE s
   SET    s.curBal=(
      SELECT SUM(curBal)
      FROM   servicerPool other
      WHERE  rptYear=s.rptYear
      AND    rptMonth=s.rptMonth
      AND    rptType=s.rptType
      AND    poolRank=s.poolRank
      AND    servicerNumber NOT IN (@n_SNumOther, @n_SNumMPF))
   FROM   servicerPool s
   WHERE  s.servicerNumber=@n_SNumOther
   AND    s.rptType=@v_type
   
   UPDATE s
   SET    s.curBal=(
      SELECT SUM(curBal)
      FROM   servicerPool
      WHERE  rptYear=s.rptYear
      AND    rptMonth=s.rptMonth
      AND    rptType=s.rptType
      AND    ((poolRank<=@n_top AND servicerNumber<>@n_SNumMPF) OR 
         servicerNumber=@n_SNumOther))
   FROM   servicerPool s
   WHERE  s.servicerNumber=@n_SNumMPF
   AND    s.rptType=@v_type

   -- Load poolData
   SET @d_rptDate=DATEADD(MONTH, -1, @d_curDate)
   SET @n_rptYear=YEAR(@d_rptDate)
   SET @n_rptMonth=MONTH(@d_rptDate)
   EXEC @n_status=loadPoolData @v_type, @n_rptYear, @n_rptMonth
   IF @n_status<>0
   BEGIN
      PRINT 'reload: Fail to call loadPoolData'
      RETURN 1
   END
   EXEC @n_status=setCurPoolData @v_type, @n_year, @n_month
   IF @n_status<>0
   BEGIN
      PRINT 'reload: Fail to call setCurPoolData'
      RETURN 1
   END

   -- adjPoolData
   SET @d_rptDate= aft.dbo.fn_yearMonthDayToDate(2000, 3, 18)
   WHILE DATEDIFF(MONTH, @d_rptDate, @d_curDate) >= 0
   BEGIN
      set @n_rptYear=YEAR(@d_rptDate)
      set @n_rptMonth=MONTH(@d_rptDate)   
      EXEC @n_status=adjPoolData @v_type, @n_rptYear, @n_rptMonth
      IF @n_status<>0
      BEGIN
         PRINT 'reload: Fail to call adjPoolData'
         RETURN 1
      END
      SET @d_rptDate=DATEADD(MONTH, 1, @d_rptDate)
   END

   -- setCPR
   SET @d_rptDate= aft.dbo.fn_yearMonthDayToDate(2000, 1, 18)
   WHILE DATEDIFF(MONTH, @d_rptDate, @d_curDate) >= 0
   BEGIN
      set @n_rptYear=YEAR(@d_rptDate)
      set @n_rptMonth=MONTH(@d_rptDate)   
      EXEC @n_status=setCPRlife @v_type, @n_rptYear, @n_rptMonth
      IF @n_status<>0
      BEGIN
         PRINT 'reload: Fail to call setCPRlife'
         RETURN 1
      END
      SET @d_rptDate=DATEADD(MONTH, 1, @d_rptDate)
   END
   EXEC @n_status=setCPR @v_type, @n_year, @n_month
   IF @n_status<>0
   BEGIN
      PRINT 'reload: Fail to call setCPR'
      RETURN 1
   END
   
   -- Load monthlyReport
   EXEC loadMonthlyReport @v_type, @v_agencyData, @n_year, @n_month

   INSERT INTO etlLog (process, timeStamp,  message)
   VALUES ('reload', getdate(), 'Ended')

