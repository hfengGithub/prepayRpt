if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SCORING_ScoresbyWAGNR]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[SCORING_ScoresbyWAGNR]
GO

CREATE TABLE [dbo].[SCORING_ScoresbyWAGNR] (
	[LoanProgram] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[OrigTerm] [smallint] NOT NULL ,
	[servicerNumber] [int] NULL ,
	[WACLow] [float] NOT NULL ,
	[AVGCPR3moDifftoBench] [float] NULL ,
	[STDCPR3moDifftoBench] [float] NULL ,
	[COUNTCPR3moDifftoBench] [int] NULL ,
	[rptType] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[numLoans] [int] NULL ,
	[ScoringByGNR] [float] NULL ,
	[bench] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

