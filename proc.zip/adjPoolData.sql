-----------------------------------------------------------------------
-- adjPoolData
-- Usage: adjCurPoolData @v_type, @n_year, @n_month
-- Parameters: 
--    v_type: indicating the report is for Chicago (C) or System (S)
--    n_year, n_month: indicating the Year, month regarded as current.
-- Comment: Called by collectData(), calling setIndPoolData(). When a PFI is added to the 
--    top 20 list, adjust the historical data for the current top 20's and AllOthers.
-----------------------------------------------------------------------

ALTER PROCEDURE adjPoolData (@v_type CHAR, @n_rptYear SMALLINT, @n_rptMonth SMALLINT) AS
   INSERT INTO etlLog (process, timeStamp,  message)
   VALUES ('adjPoolData', getdate(), 'Started')

DECLARE @n_rankOther SMALLINT
   SET @n_rankOther=(SELECT refValue FROM rptReference WHERE refCode='RANKOTHER')
DECLARE @d_prevDate DATETIME
   SET @d_prevDate=DATEADD(MONTH, -1, aft.dbo.fn_yearMonthDayToDate(@n_rptYear, @n_rptMonth, 18))
   PRINT 'adjPoolData: started'

DECLARE c CURSOR FOR
   SELECT servicerNumber, poolRank FROM servicerPool s
   WHERE  rptYear=@n_rptYear
   AND    rptMonth=@n_rptMonth
   AND    rptType=@v_type
   AND    poolRank<@n_rankOther
   AND    servicerNumber NOT IN (
      SELECT servicerNumber FROM servicerPool p 
      WHERE  p.poolrank<@n_rankOther 
      AND    rptType=@v_type
      AND    rptYear=YEAR(@d_prevDate)
      AND    rptMonth=MONTH(@d_prevDate))

DECLARE @n_servicerNumber INT, @n_rank SMALLINT, @n_counter SMALLINT
   SET @n_counter=0

   OPEN c
   FETCH NEXT FROM c INTO @n_servicerNumber, @n_rank
   WHILE (@@FETCH_STATUS<>-1)
   BEGIN
      SET @n_counter=@n_counter+1
      EXEC setIndPoolData @v_type, @n_rptYear, @n_rptMonth, @n_servicerNumber, @n_rank
      FETCH NEXT FROM c INTO @n_servicerNumber, @n_rank
   END
   
   CLOSE c
   DEALLOCATE c
   
   IF @n_counter>0
   BEGIN
      SET @n_servicerNumber=(
         SELECT servicerNumber FROM servicer WHERE servicerName='All Others')
      EXEC setIndPoolData @v_type, @n_rptYear, @n_rptMonth, @n_servicerNumber, @n_rankOther      
   END

   INSERT INTO etlLog (process, timeStamp,  message)
   VALUES ('adjPoolData', getdate(), 'Ended')
   PRINT 'adjPoolData: Ended'

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

