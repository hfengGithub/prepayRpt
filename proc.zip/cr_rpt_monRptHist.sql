if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[rpt_monRptHist]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[rpt_monRptHist]
GO

CREATE TABLE [dbo].[rpt_monRptHist] (
	[agency] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[servicerNumber] [int] NULL ,
	[ServicerName] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[OrigTerm] [smallint] NOT NULL ,
	[LoanProgram] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[GrossCoupon] [real] NOT NULL ,
	[GrossCouponInt] [float] NOT NULL ,
	[NetCoupon] [real] NULL ,
	[OrigYear] [smallint] NOT NULL ,
	[FactorCalc] [real] NULL ,
	[OrigBal] [float] NULL ,
	[CurrentBal] [float] NULL ,
	[WALA] [smallint] NULL ,
	[CPR1Month] [real] NULL ,
	[CPR3Month] [real] NULL ,
	[CPR6Month] [real] NULL ,
	[CPR12Month] [real] NULL ,
	[CPRLife] [real] NULL ,
	[Source] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[showRank] [int] NULL ,
	[rptType] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[bal3MonBefore] [float] NULL ,
	[numLoans] [int] NULL ,
	[numLoans3MonBefore] [int] NULL ,
	[rptYearMonth] [int] NULL ,
	[WACspread] [real] NULL ,
	[sumChgoPart] [real] NULL 
) ON [PRIMARY]
GO

