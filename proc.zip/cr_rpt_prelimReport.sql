if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[rpt_prelimReport]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[rpt_prelimReport]
GO

CREATE TABLE [dbo].[rpt_prelimReport] (
	[servicerNumber] [int] NULL ,
	[ServicerName] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[OrigTerm] [smallint] NOT NULL ,
	[LoanProgram] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[OrigYear] [smallint] NOT NULL ,
	[WAClow] [float] NOT NULL ,
	[GrossCoupon] [real] NOT NULL ,
	[CPR1] [real] NULL ,
	[estCPR1] [real] NULL ,
	[estCurBal] [real] NULL ,
	[curBal] [real] NULL ,
	[preBal] [float] NULL ,
	[WALA] [int] NULL ,
	[CPR1Month] [real] NULL ,
	[CPR3Month] [real] NULL ,
	[CPR6Month] [real] NULL ,
	[chgBal] [real] NULL ,
	[rptYearMonth] [int] NULL ,
	[schPrincipal] [float] NULL 
) ON [PRIMARY]
GO

