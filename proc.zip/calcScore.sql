--------------------------------------------------------------------------
-- Procedure: calcScore
-- Usage: calcScore @v_bench, @n_year, @n_month
-- Parameters: 
--    v_bench: indicating the score is relative to the bench mark FNMA, FHLMC or MPF.
--    n_year, n_month: indicating the Year, month regarded as current (default=current).
-- Comment: Called by collectData(), compares prepayment of the top 20 PFIs, all others 
--    and MPF with bench mark, puts their scores into scoring_final table.
--------------------------------------------------------------------------

ALTER PROC calcScore
   @v_bench VARCHAR(20),
   @n_year SMALLINT=NULL, 
   @n_month SMALLINT=NULL 
AS
   IF (@n_year IS NULL)
   BEGIN
      SET @n_year=YEAR(getdate())
      SET @n_month=MONTH(getdate())
   END
   PRINT 'calcScore: started'

   IF @v_bench='A'
   BEGIN
      TRUNCATE TABLE SCORING_Diff_to_Benchmark
      TRUNCATE TABLE SCORING_AvgDiff
      TRUNCATE TABLE SCORING_ScoresbyWAGNR
      TRUNCATE TABLE SCORING_summary
      TRUNCATE TABLE SCORING_summary_brk
      TRUNCATE TABLE SCORING_final
      EXEC calcScore 'MPF', @n_year, @n_month
      EXEC calcScore 'FNMA', @n_year, @n_month
      EXEC calcScore 'FHLMC', @n_year, @n_month
   END
   ELSE
   BEGIN
      DELETE SCORING_Diff_to_Benchmark WHERE bench=@v_bench
      DELETE SCORING_AvgDiff           WHERE bench=@v_bench
      DELETE SCORING_ScoresbyWAGNR     WHERE bench=@v_bench
      DELETE SCORING_summary           WHERE bench=@v_bench
      DELETE SCORING_summary_brk       WHERE bench=@v_bench
      DELETE SCORING_final             WHERE bench=@v_bench

      -- Calculate the difference between CPR3month of each servicer's and that of MPF's for each pool
      INSERT INTO   SCORING_Diff_to_Benchmark (
           LoanProgram,
           OrigTerm,
           OrigYear,
           BENCHOrigYear,
           WACLow,
           ServicerNumber,
           rptType,
           numLoans3MonBefore,
           bal3MonBefore,
           OrigBal,
           CPR3moBench,
           CPR3moServ,
           CPR3moDifftoBench,
           numLoans,
           numLoansLag3Hat,
           SMM3moServ,
           SMM3moBench,
           CI01, CI05, CI10, CI20, CI40, CI60, CI80, CI90, CI95, CI99,
           poolFlag,
           poolScore,
           bench)
      SELECT p.LoanProgram, p.OrigTerm, p.OrigYear, BENCHMARK.OrigYear AS  BENCHOrigYear, 
             p.GrossCouponInt as WACLow, p.ServicerNumber, p.rptType, p.numLoans3MonBefore, p.bal3MonBefore,
             p.OrigBal, BENCHMARK.CPR3Month As CPR3moBench, p.CPR3Month AS CPR3moServ,
             BENCHMARK.CPR3Month - p.CPR3Month AS CPR3moDifftoBench, p.numLoans, 0 AS numLoansLag3Hat,
             SMM3moServ=1-Power(1-p.CPR3Month/100, .25), 
             SMM3moBench=1-Power(1-BENCHMARK.CPR3Month/100, .25),  
             0 AS CI01, 0 AS CI05, 0 AS CI10, 0 AS CI20, 0 AS CI40, 0 AS CI60, 0 AS CI80, 0 AS CI90, 
             0 AS CI95 , 0 AS CI99 ,Cast('White' AS varchar(6)) AS poolFlag, 0 AS poolScore, @v_bench
      FROM   monthlyReport BENCHMARK INNER JOIN monthlyReport AS p      
      ON     BENCHMARK.OrigYear = p.OrigYear 
      AND    BENCHMARK.OrigTerm = p.OrigTerm 
      AND    BENCHMARK.LoanProgram = p.LoanProgram 
      AND    BENCHMARK.GrossCouponInt = p.GrossCouponInt 
      WHERE  BENCHMARK.ServicerName LIKE @v_bench+'%' 
      AND    BENCHMARK.ServicerName NOT LIKE '%(all)'
      AND    BENCHMARK.CPR3Month Is not Null
      AND    (BENCHMARK.rptType IS NULL OR (BENCHMARK.rptType=p.rptType AND BENCHMARK.ServicerNumber<>p.ServicerNumber))
      AND    p.rptType IN ('C', 'S') 
      AND    p.LoanProgram='Conventional'
      AND    p.CPR3Month Is not Null
      AND    p.bal3MonBefore >=5  
      AND    p.OrigYear>2000
      
      INSERT INTO SCORING_AvgDiff
      SELECT LoanProgram,  OrigTerm, WACLow, ServicerNumber, 
             SUM(bal3MonBefore*CPR3moDifftoBench)/SUM(bal3MonBefore) AS AvgDiffToBenchAux, 
             Count(CPR3moDifftoBench) AS PoolsPerWAGNR, rptType, SUM(numLoans) numLoans, @v_bench
      FROM   SCORING_Diff_to_Benchmark
      WHERE  bench=@v_bench
      GROUP BY LoanProgram, OrigTerm, WACLow, ServicerNumber, rptType
       
      INSERT INTO SCORING_ScoresbyWAGNR
      SELECT diff.LoanProgram, diff.OrigTerm, diff.servicerNumber, diff.WACLow, MAX(AvgDiffToBenchAux) AS AVGCPR3moDifftoBench,
      	Power(Sum(Power(diff.CPR3moDifftoBench- AvgDiffToBenchAux,2))/Count(CPR3moDifftoBench),.5)AS STDCPR3moDifftoBench,
      	Count(CPR3moDifftoBench)  AS COUNTCPR3moDifftoBench, diff.rptType, SUM(diff.numLoans) numLoans,
        -- Avg(CPR3moDifftoBench)-Power(Sum(Power(diff.CPR3moDifftoBench- AvgDiffToBenchAux,2))/Count(CPR3moDifftoBench),.5) AS ScoringByGNR
      	MAX(AvgDiffToBenchAux)-Power(Sum(Power(diff.CPR3moDifftoBench- AvgDiffToBenchAux,2))/Count(CPR3moDifftoBench),.5) AS ScoringByGNR,
      	@v_bench
      FROM   SCORING_Diff_to_Benchmark diff INNER JOIN SCORING_AvgDiff avgdiff
      ON     diff.LoanProgram = avgdiff.LoanProgram 
      AND    diff.OrigTerm = avgdiff.OrigTerm 
      AND    diff.WACLow= avgdiff.WACLow
      AND    diff.servicerNumber = avgdiff.servicerNumber 
      AND    diff.rptType = avgdiff.rptType 
      AND    diff.bench = avgdiff.bench
      WHERE  diff.bench = @v_bench
      GROUP BY diff.LoanProgram,  diff.OrigTerm, diff.WACLow, diff.servicerNumber, diff.rptType
      
      -- Create the summary scores
      INSERT INTO SCORING_summary_brk
      SELECT ss.loanProgram, ss.origTerm, ss.rptType, m.servicerNumber, m.servicerName, 
             SUM(m.bal3MonBefore*AVGCPR3moDifftoBench)/SUM(m.bal3MonBefore) AS FinalVGCPR3moDifftoBench,
             SUM(m.bal3MonBefore*STDCPR3moDifftoBench)/SUM(m.bal3MonBefore) AS FinalSTDCPR3moDifftoBench,
             SUM(m.bal3MonBefore*ScoringByGNR)/SUM(m.bal3MonBefore) AS FinalScore, 
             SUM(m.bal3MonBefore) AS bal3MonBefore,
             STDev(ss.ScoringByGNR) AS OveralSTd, Min(ss.ScoringByGNR) Min, Max(ss.ScoringByGNR) Max, 
             SUM(COUNTCPR3moDifftoBench) AS TotalNumberPools, SUM(ss.numLoans) numLoans, @v_bench as bench
      -- INTO SCORING_summary_brk
      FROM   SCORING_ScoresbyWAGNR AS ss, (
         SELECT loanProgram, origTerm, servicerNumber, servicerName, rptType, GrossCouponInt,
            SUM(bal3MonBefore) AS bal3MonBefore  
         FROM   reports.dbo.monthlyReport
         WHERE  bal3MonBefore>=5
         GROUP BY loanProgram, origTerm, servicerNumber, servicerName, rptType, GrossCouponInt) AS m
      WHERE  ss.servicerNumber=m.servicerNumber
      AND    ss.loanProgram=m.loanProgram
      AND    ss.origTerm=m.origTerm
      AND    ss.rptType=m.rptType
      AND    ss.WACLow=m.GrossCouponInt
      AND    ss.bench=@v_bench
      AND    m.bal3MonBefore >=5
      GROUP BY ss.loanProgram, ss.origTerm, ss.rptType, m.servicerNumber, m.servicerName
      
      -- Create the final scores
      INSERT INTO SCORING_final
      SELECT ss.loanProgram, ss.rptType, m.servicerNumber, m.servicerName, 
             SUM(m.bal3MonBefore*ScoringByGNR)/SUM(m.bal3MonBefore) AS FinalScore, 
             SUM(m.bal3MonBefore*(ScoringByGNR+STDCPR3moDifftoBench))/SUM(m.bal3MonBefore) AS meanComponent, 
             SUM(m.bal3MonBefore*STDCPR3moDifftoBench)/SUM(m.bal3MonBefore) AS stdComponent, 
             STDev(ScoringByGNR) AS OveralSTd, Min(ScoringByGNR) MinScore, Max(ScoringByGNR) MaxScore, 
             SUM(ss.COUNTCPR3moDifftoBench) AS numPools, SUM(ss.numLoans) AS numLoans,
             aveLoanSize=1000000*(CASE WHEN ss.rptType='C' THEN SUM(m.curBal)/(SUM(m.ChgoPart)+.0001) 
                         ELSE SUM(m.curBal)/SUM(ss.numLoans) END),
             bench=@v_bench
      FROM   SCORING_ScoresbyWAGNR AS ss, (
         SELECT loanProgram, origTerm, servicerNumber, servicerName, rptType, GrossCouponInt,
            SUM(bal3MonBefore) AS bal3MonBefore,
            SUM(ISNULL(currentBal,0)) curBal, SUM(ISNULL(sumChgoPart,0)) ChgoPart 
         FROM   monthlyReport
         WHERE  bal3MonBefore>=5
         GROUP BY loanProgram, origTerm, servicerNumber, servicerName, rptType, GrossCouponInt) AS m
      WHERE  ss.servicerNumber=m.servicerNumber
      AND    ss.loanProgram=m.loanProgram
      AND    ss.origTerm=m.origTerm
      AND    ss.rptType=m.rptType
      AND    ss.WACLow=m.GrossCouponInt
      AND    ss.bench=@v_bench
      AND    m.bal3MonBefore >=5
      GROUP BY ss.loanProgram, m.servicerNumber, m.servicerName, ss.rptType 
      
      PRINT 'calcScore: ended'
   END

