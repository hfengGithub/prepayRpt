----------------------------------------------------------------
-- Procedure: setPoolData 
-- Usage: setPoolData @v_type, @n_year, @n_month
-- Parameters: 
--    v_type: indicating the report is for Chicago (C) or System (S)
--    n_year, n_month: regarded the year, month as current period.
-- Comment: stand-alone procedure, used when re-loading one month data, loading historical 
--    data for a specific month into poolData.
----------------------------------------------------------------

ALTER PROCEDURE setPoolData(@v_type CHAR, @n_year SMALLINT, @n_month SMALLINT) AS
DECLARE 
   @n_invSpan REAL,
   @n_WACSpan REAL,
   @n_yearInit SMALLINT, @n_origYear SMALLINT,
   @n_adjYearMonth INT

   INSERT INTO etlLog (process, timeStamp,  message)
   VALUES ('setPoolData', getdate(), 'Started')

-- init values
   SET @n_yearInit=(SELECT  refValue FROM rptReference WHERE refCode='STARTYEAR')
   SET @n_WACSpan=(SELECT  refValue FROM rptReference WHERE refCode='WACSPAN')

   SET @n_adjYearMonth=100*@n_Year + @n_month
   SET @n_invSpan=ROUND(1/@n_WACSpan, 0)

   
   IF @v_type='C'
      INSERT INTO poolData (
         rptYear ,
         rptMonth ,
         origYear,
         origTerm,
         loanProgram,
         servicerNumber,
         WACLow,
         WAC,
         poolFactor,
         origBal,
         curBal ,
         prevBal ,
         SMM,
         WALA,
         adjYearMonth, rptType)    
      SELECT @n_Year, @n_month,
         YEAR(m.origDate),
         m.origTerm,
         m.loanProgram,
         p1.servicerNumber,
         WACLow=-@n_WACSpan+CEILING(ROUND(@n_invSpan*ah.grossCoupon, 5))/@n_invSpan,
         WAC=SUM(ISNULL(ah.grossCoupon*ah.currentBal*cp.chicagoParticipation,0))/
            (SUM(ISNULL(ah.currentBal*cp.chicagoParticipation,0))+.0001), 
         poolFactor=SUM(ISNULL(ah.currentBal*cp.chicagoParticipation,0)) /
            (SUM(m.OrigBal*cp.chicagoParticipation)+.0001), 
         SUM(m.OrigBal*cp.chicagoParticipation),
         curBal=SUM(ISNULL(ah.currentBal*cp.chicagoParticipation,0)),
         prevBal=SUM(ISNULL(ah.PreviousBal*cp.chicagoParticipation,0)), 
         SMM=SUM(ISNULL(ah.PreviousBal*cp.chicagoParticipation*ah.SMM/100,0))/
            (SUM(ISNULL(ah.PreviousBal*cp.chicagoParticipation,0))+.000001),
         WALA=SUM(ISNULL(ah.WALA*ah.currentBal*cp.chicagoParticipation,0))/
                    (SUM(ISNULL(ah.currentBal*cp.chicagoParticipation,0))+.000001),
         @n_adjYearMonth , @v_type          
      FROM   servicerPool p, servicerPool p1, AFT.dbo.AFTMaster m, AFT.dbo.aftHistory ah, 
             aft_work.dbo.chicagoParticipation_loanLevel cp 
      WHERE  m.OrigBal> 0
      AND    m.origTerm>=180
      AND    Year(m.OrigDate) >= @n_yearInit
      AND    m.agency='FHLB'
      AND    m.loanIDnumber=ah.loanIDnumber
      AND    ah.HistYear=@n_year AND ah.histMonth=@n_month
      AND    p.servicerNumber=m.servicerNumber               
      AND    p.rptYear=ah.HistYear
      AND    p.rptMonth=ah.histMonth
      AND    p.rptType=@v_type
      AND    p1.rptYear=ah.histYear
      AND    p1.rptMonth=ah.histMonth
      AND    p1.rptType=@v_type
      AND    p1.poolRank=p.poolRank
      AND    p1.servicerNumber=(
         SELECT MIN(servicerNumber) FROM servicerPool 
         WHERE  rptYear=ah.histYear AND rptMonth=ah.histMonth AND poolRank=p1.poolRank)
      AND    cp.loanNumber=m.loanIDnumber
      GROUP BY m.loanProgram, YEAR(m.origDate), m.origTerm, 
         -@n_WACSpan+CEILING(ROUND(@n_invSpan*ah.grossCoupon, 5))/@n_invSpan, p1.servicerNumber
   ELSE
      INSERT INTO poolData (
         rptYear ,
         rptMonth ,
         origYear,
         origTerm,
         loanProgram,
         servicerNumber,
         WACLow,
         WAC,
         poolFactor,
         origBal,
         curBal ,
         prevBal ,
         SMM,
         WALA,
         adjYearMonth, rptType)    
      SELECT @n_Year, @n_month,
         YEAR(m.origDate),
         m.origTerm,
         m.loanProgram,
         p1.servicerNumber,
         WACLow=-@n_WACSpan+CEILING(ROUND(@n_invSpan*ah.grossCoupon, 5))/@n_invSpan,
         WAC=SUM(ISNULL(ah.grossCoupon*ah.currentBal,0))/(SUM(ISNULL(ah.currentBal,0))+.0001), 
         poolFactor=SUM(ISNULL(ah.currentBal,0))/(SUM(m.OrigBal)+.0001), 
         SUM(m.OrigBal),
         curBal=SUM(ISNULL(ah.currentBal,0)),
         prevBal=SUM(ISNULL(ah.PreviousBal,0)), 
         SMM=SUM(ISNULL(ah.PreviousBal*ah.SMM/100,0))/(SUM(ISNULL(ah.PreviousBal,0))+.000001),
         WALA=SUM(ISNULL(ah.WALA*ah.currentBal,0))/(SUM(ISNULL(ah.currentBal,0))+.000001),
         @n_adjYearMonth , @v_type          
      FROM   servicerPool p, servicerPool p1, AFT.dbo.AFTMaster m, AFT.dbo.aftHistory ah
      WHERE  m.OrigBal> 0
      AND    m.origTerm>=180
      AND    Year(m.OrigDate) >= @n_yearInit
      AND    m.agency='FHLB'
      AND    m.loanIDnumber=ah.loanIDnumber
      AND    ah.HistYear=@n_year AND ah.histMonth=@n_month
      AND    p.servicerNumber=m.servicerNumber               
      AND    p.rptYear=ah.HistYear
      AND    p.rptMonth=ah.histMonth
      AND    p.rptType=@v_type
      AND    p1.rptYear=ah.histYear
      AND    p1.rptMonth=ah.histMonth
      AND    p1.rptType=@v_type
      AND    p1.poolRank=p.poolRank
      AND    p1.servicerNumber=(
         SELECT MIN(servicerNumber) FROM servicerPool 
         WHERE  rptYear=ah.histYear AND rptMonth=ah.histMonth AND poolRank=p1.poolRank)
      GROUP BY m.loanProgram, YEAR(m.origDate), m.origTerm, 
         -@n_WACSpan+CEILING(ROUND(@n_invSpan*ah.grossCoupon, 5))/@n_invSpan, p1.servicerNumber

   -- Create MPF records
   INSERT INTO poolData (
      rptYear ,
      rptMonth ,
      origYear,
      origTerm,
      loanProgram,
      servicerNumber,
      WACLow,
      WAC,
      poolFactor,
      origBal,
      curBal ,
      prevBal ,
      SMM,
      WALA,
      adjYearMonth, rptType)
   SELECT  
      @n_Year ,
      @n_Month ,
      origYear,
      origTerm,
      loanProgram,
      s.servicerNumber,
      WACLow,
      SUM(WAC*CurBal)/(SUM(CurBal)+.0001), 
      SUM(CurBal) /(SUM(OrigBal)+.0001), 
      SUM(OrigBal),
      curBal=SUM(CurBal),
      prevBal=SUM(PrevBal), 
      SMM=SUM(PrevBal*SMM)/(SUM(PrevBal)+.000001),
      WALA=ROUND(SUM(WALA*CurBal)/(SUM(CurBal)+.000001), 0),
      @n_adjYearMonth, @v_type
   FROM   poolData p, servicer s
   WHERE  rptYear=@n_Year
   AND    rptMonth=@n_Month
   AND    p.rptType=@v_type
   AND    s.servicerName='MPF'
   GROUP BY origYear, origTerm, loanProgram, WACLow, s.servicerNumber

   INSERT INTO etlLog (process, timeStamp,  message)
   VALUES ('setPoolData', getdate(), 'Ended')

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

