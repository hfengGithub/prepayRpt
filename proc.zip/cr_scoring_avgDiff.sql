if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SCORING_AvgDiff]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[SCORING_AvgDiff]
GO

CREATE TABLE [dbo].[SCORING_AvgDiff] (
	[LoanProgram] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[OrigTerm] [smallint] NOT NULL ,
	[WACLow] [float] NOT NULL ,
	[ServicerNumber] [int] NULL ,
	[AvgDiffToBenchAux] [float] NULL ,
	[PoolsPerWAGNR] [int] NULL ,
	[rptType] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[numLoans] [int] NULL ,
	[bench] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

