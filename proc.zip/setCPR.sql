--------------------------------------------------------------------------
-- Procedure: setCPR
-- Usage: setCPR @v_type, @n_year, @n_month
-- Parameters: 
--    v_type: indicating the report is for Chicago (C) or System (S)
--    n_year, n_month: indicating the Year, month regarded as current.
-- Comment: Called by collectData(), calling setCPRothers(), calculates CPR1 for all periods, 
--    and calculates CPR3, CPR6 and CPR12 for the current period.
--------------------------------------------------------------------------

ALTER PROCEDURE setCPR (@v_type CHAR, @n_rptYear SMALLINT, @n_rptMonth SMALLINT) AS
   INSERT INTO etlLog (process, timeStamp,  message)
   VALUES ('setCPR', getdate(), 'Started')
   PRINT 'setCPR: started'
DECLARE @d_rptDate DATETIME
   SET @d_rptDate= aft.dbo.fn_yearMonthDayToDate(@n_rptYear, @n_rptMonth, 18)
DECLARE @n_adjYearMonth INT
   SET @n_adjYearMonth=100*@n_rptYear + @n_rptMonth
DECLARE @n_sNumOthers INT
   SET @n_sNumOthers=(SELECT servicerNumber FROM servicer WHERE servicerName='All Others')

   EXEC setCPRothers @v_type, @n_rptYear, @n_rptMonth
   
   -- CPR1Month
   UPDATE PoolData	
   SET    CPR1Month=1-Power((1-SMM), 12)
--   WHERE  rptYear=@n_rptYear
--   AND    rptMonth=@n_rptMonth       
--   AND    rptType=@v_type

   TRUNCATE TABLE t_poolData
   INSERT INTO t_poolData (
      rptYear ,
      rptMonth ,
      origYear,
      origTerm,
      loanProgram,
      servicerNumber,
      WACLow,
      SMM,
      WALA,
      adjYearMonth, 
      rptType)
   SELECT 
      rptYear ,
      rptMonth ,
      origYear,
      origTerm,
      loanProgram,
      servicerNumber,
      WACLow,
      SMM,
      WALA,
      adjYearMonth, 
      rptType
   FROM   poolData 
   WHERE  rptType=@v_type
   AND    servicerNumber<>@n_sNumOthers
   AND    100*rptYear+rptMonth > @n_adjYearMonth-100

   -- CPR3Month
   UPDATE d1	
   SET    CPR3Month=1-Power((1-d1.SMM)*(1-d2.SMM)*(1-d3.SMM), 4)
   FROM   PoolData d1, t_poolData d2, t_poolData d3
   WHERE  d1.rptYear=@n_rptYear
   AND    d1.rptMonth=@n_rptMonth  
   AND    d1.WALA>=2.5  
   AND    d1.servicerNUmber<>@n_sNumOthers
   AND    d1.rptType=@v_type
   AND    d2.origYear=d1.origYear
   AND    d2.origTerm=d1.origTerm
   AND    d2.loanProgram=d1.loanProgram
   AND    d2.WACLow=d1.WACLow
   AND    d2.servicerNumber=d1.servicerNumber
   AND    d2.rptType=@v_type
   AND    DATEDIFF(MONTH, aft.dbo.fn_yearMonthDayToDate(d2.rptYear, d2.rptMonth, 18), 
                          aft.dbo.fn_yearMonthDayToDate(d1.rptYear, d1.rptMonth, 18))=1  
   AND    d1.adjYearMonth-d2.adjYearMonth IN (0, 1, 89)
   AND    d3.origYear=d1.origYear
   AND    d3.origTerm=d1.origTerm
   AND    d3.loanProgram=d1.loanProgram
   AND    d3.WACLow=d1.WACLow
   AND    d3.servicerNumber=d1.servicerNumber
   AND    d3.rptType=@v_type
   AND    DATEDIFF(MONTH, aft.dbo.fn_yearMonthDayToDate(d3.rptYear, d3.rptMonth, 18), 
                          aft.dbo.fn_yearMonthDayToDate(d2.rptYear, d2.rptMonth, 18))=1  
   AND    d2.adjYearMonth-d3.adjYearMonth IN (0, 1, 89)
   
   -- CPR6Month
   UPDATE d1	
   SET    CPR6Month=1-Power((1-d1.SMM)*(1-d2.SMM)*(1-d3.SMM)*(1-d4.SMM)*(1-d5.SMM)*(1-d6.SMM), 2)
   FROM   PoolData d1, t_poolData d2, t_poolData d3, t_poolData d4, t_poolData d5, t_poolData d6
   WHERE  d1.rptYear=@n_rptYear
   AND    d1.rptMonth=@n_rptMonth  
   AND    d1.WALA>=5.5  
   AND    d1.servicerNUmber<>@n_sNumOthers
   AND    d1.rptType=@v_type
   AND    d2.origYear=d1.origYear
   AND    d2.origTerm=d1.origTerm
   AND    d2.loanProgram=d1.loanProgram
   AND    d2.WACLow=d1.WACLow
   AND    d2.servicerNumber=d1.servicerNumber
   AND    d2.rptType=@v_type
   AND    DATEDIFF(MONTH, aft.dbo.fn_yearMonthDayToDate(d2.rptYear, d2.rptMonth, 18), 
                          aft.dbo.fn_yearMonthDayToDate(d1.rptYear, d1.rptMonth, 18))=1  
   AND    d1.adjYearMonth-d2.adjYearMonth IN (0, 1, 89)
   AND    d3.origYear=d1.origYear
   AND    d3.origTerm=d1.origTerm
   AND    d3.loanProgram=d1.loanProgram
   AND    d3.WACLow=d1.WACLow
   AND    d3.servicerNumber=d1.servicerNumber
   AND    d3.rptType=@v_type
   AND    DATEDIFF(MONTH, aft.dbo.fn_yearMonthDayToDate(d3.rptYear, d3.rptMonth, 18), 
                          aft.dbo.fn_yearMonthDayToDate(d2.rptYear, d2.rptMonth, 18))=1  
   AND    d2.adjYearMonth-d3.adjYearMonth IN (0, 1, 89)
   AND    d4.origYear=d1.origYear
   AND    d4.origTerm=d1.origTerm
   AND    d4.loanProgram=d1.loanProgram
   AND    d4.WACLow=d1.WACLow
   AND    d4.servicerNumber=d1.servicerNumber
   AND    d4.rptType=@v_type
   AND    DATEDIFF(MONTH, aft.dbo.fn_yearMonthDayToDate(d4.rptYear, d4.rptMonth, 18), 
                          aft.dbo.fn_yearMonthDayToDate(d3.rptYear, d3.rptMonth, 18))=1  
   AND    d3.adjYearMonth-d4.adjYearMonth IN (0, 1, 89)
   AND    d5.origYear=d1.origYear
   AND    d5.origTerm=d1.origTerm
   AND    d5.loanProgram=d1.loanProgram
   AND    d5.WACLow=d1.WACLow
   AND    d5.servicerNumber=d1.servicerNumber
   AND    d5.rptType=@v_type
   AND    DATEDIFF(MONTH, aft.dbo.fn_yearMonthDayToDate(d5.rptYear, d5.rptMonth, 18), 
                          aft.dbo.fn_yearMonthDayToDate(d4.rptYear, d4.rptMonth, 18))=1  
   AND    d4.adjYearMonth-d5.adjYearMonth IN (0, 1, 89)
   AND    d6.origYear=d1.origYear
   AND    d6.origTerm=d1.origTerm
   AND    d6.loanProgram=d1.loanProgram
   AND    d6.WACLow=d1.WACLow
   AND    d6.servicerNumber=d1.servicerNumber
   AND    d6.rptType=@v_type
   AND    DATEDIFF(MONTH, aft.dbo.fn_yearMonthDayToDate(d6.rptYear, d6.rptMonth, 18), 
                          aft.dbo.fn_yearMonthDayToDate(d5.rptYear, d5.rptMonth, 18))=1  
   AND    d5.adjYearMonth-d6.adjYearMonth IN (0, 1, 89)


   -- CPR1Year
   UPDATE d1	
   SET    CPR1year=1-(1-d1.SMM)*(1-d2.SMM)*(1-d3.SMM)*(1-d4.SMM)*(1-d5.SMM)*(1-d6.SMM)*
                     (1-d7.SMM)*(1-d8.SMM)*(1-d9.SMM)*(1-d10.SMM)*(1-d11.SMM)*(1-d12.SMM)
   FROM   PoolData d1, t_poolData d2, t_poolData d3, t_poolData d4, t_poolData d5, t_poolData d6,
          t_poolData d7, t_poolData d8, t_poolData d9, t_poolData d10, t_poolData d11, t_poolData d12
   WHERE  d1.rptYear=@n_rptYear
   AND    d1.rptMonth=@n_rptMonth  
   AND    d1.WALA>=11.5 
   AND    d1.servicerNUmber<>@n_sNumOthers
   AND    d1.rptType=@v_type
   AND    d2.origYear=d1.origYear
   AND    d2.origTerm=d1.origTerm
   AND    d2.loanProgram=d1.loanProgram
   AND    d2.WACLow=d1.WACLow
   AND    d2.servicerNumber=d1.servicerNumber
   AND    d2.rptType=@v_type
   AND    DATEDIFF(MONTH, aft.dbo.fn_yearMonthDayToDate(d2.rptYear, d2.rptMonth, 18), 
                          aft.dbo.fn_yearMonthDayToDate(d1.rptYear, d1.rptMonth, 18))=1  
   AND    d1.adjYearMonth-d2.adjYearMonth IN (0, 1, 89)
   AND    d3.origYear=d1.origYear
   AND    d3.origTerm=d1.origTerm
   AND    d3.loanProgram=d1.loanProgram
   AND    d3.WACLow=d1.WACLow
   AND    d3.servicerNumber=d1.servicerNumber
   AND    d3.rptType=@v_type
   AND    DATEDIFF(MONTH, aft.dbo.fn_yearMonthDayToDate(d3.rptYear, d3.rptMonth, 18), 
                          aft.dbo.fn_yearMonthDayToDate(d2.rptYear, d2.rptMonth, 18))=1  
   AND    d2.adjYearMonth-d3.adjYearMonth IN (0, 1, 89)
   AND    d4.origYear=d1.origYear
   AND    d4.origTerm=d1.origTerm
   AND    d4.loanProgram=d1.loanProgram
   AND    d4.WACLow=d1.WACLow
   AND    d4.servicerNumber=d1.servicerNumber
   AND    d4.rptType=@v_type
   AND    DATEDIFF(MONTH, aft.dbo.fn_yearMonthDayToDate(d4.rptYear, d4.rptMonth, 18), 
                          aft.dbo.fn_yearMonthDayToDate(d3.rptYear, d3.rptMonth, 18))=1  
   AND    d3.adjYearMonth-d4.adjYearMonth IN (0, 1, 89)
   AND    d5.origYear=d1.origYear
   AND    d5.origTerm=d1.origTerm
   AND    d5.loanProgram=d1.loanProgram
   AND    d5.WACLow=d1.WACLow
   AND    d5.servicerNumber=d1.servicerNumber
   AND    d5.rptType=@v_type
   AND    DATEDIFF(MONTH, aft.dbo.fn_yearMonthDayToDate(d5.rptYear, d5.rptMonth, 18), 
                          aft.dbo.fn_yearMonthDayToDate(d4.rptYear, d4.rptMonth, 18))=1  
   AND    d4.adjYearMonth-d5.adjYearMonth IN (0, 1, 89)
   AND    d6.origYear=d1.origYear
   AND    d6.origTerm=d1.origTerm
   AND    d6.loanProgram=d1.loanProgram
   AND    d6.WACLow=d1.WACLow
   AND    d6.servicerNumber=d1.servicerNumber
   AND    d6.rptType=@v_type
   AND    DATEDIFF(MONTH, aft.dbo.fn_yearMonthDayToDate(d6.rptYear, d6.rptMonth, 18), 
                          aft.dbo.fn_yearMonthDayToDate(d5.rptYear, d5.rptMonth, 18))=1  
   AND    d5.adjYearMonth-d6.adjYearMonth IN (0, 1, 89)
   AND    d7.origYear=d1.origYear
   AND    d7.origTerm=d1.origTerm
   AND    d7.loanProgram=d1.loanProgram
   AND    d7.WACLow=d1.WACLow
   AND    d7.servicerNumber=d1.servicerNumber
   AND    d7.rptType=@v_type
   AND    DATEDIFF(MONTH, aft.dbo.fn_yearMonthDayToDate(d7.rptYear, d7.rptMonth, 18), 
                          aft.dbo.fn_yearMonthDayToDate(d6.rptYear, d6.rptMonth, 18))=1  
   AND    d6.adjYearMonth-d7.adjYearMonth IN (0, 1, 89)
   AND    d8.origYear=d1.origYear
   AND    d8.origTerm=d1.origTerm
   AND    d8.loanProgram=d1.loanProgram
   AND    d8.WACLow=d1.WACLow
   AND    d8.servicerNumber=d1.servicerNumber
   AND    d8.rptType=@v_type
   AND    DATEDIFF(MONTH, aft.dbo.fn_yearMonthDayToDate(d8.rptYear, d8.rptMonth, 18), 
                          aft.dbo.fn_yearMonthDayToDate(d7.rptYear, d7.rptMonth, 18))=1  
   AND    d7.adjYearMonth-d8.adjYearMonth IN (0, 1, 89)
   AND    d9.origYear=d1.origYear
   AND    d9.origTerm=d1.origTerm
   AND    d9.loanProgram=d1.loanProgram
   AND    d9.WACLow=d1.WACLow
   AND    d9.servicerNumber=d1.servicerNumber
   AND    d9.rptType=@v_type
   AND    DATEDIFF(MONTH, aft.dbo.fn_yearMonthDayToDate(d9.rptYear, d9.rptMonth, 18), 
                          aft.dbo.fn_yearMonthDayToDate(d8.rptYear, d8.rptMonth, 18))=1  
   AND    d8.adjYearMonth-d9.adjYearMonth IN (0, 1, 89)
   AND    d10.origYear=d1.origYear
   AND    d10.origTerm=d1.origTerm
   AND    d10.loanProgram=d1.loanProgram
   AND    d10.WACLow=d1.WACLow
   AND    d10.servicerNumber=d1.servicerNumber
   AND    d10.rptType=@v_type
   AND    DATEDIFF(MONTH, aft.dbo.fn_yearMonthDayToDate(d10.rptYear, d10.rptMonth, 18), 
                          aft.dbo.fn_yearMonthDayToDate(d9.rptYear, d9.rptMonth, 18))=1  
   AND    d4.adjYearMonth-d5.adjYearMonth IN (0, 1, 89)
   AND    d11.origYear=d1.origYear
   AND    d11.origTerm=d1.origTerm
   AND    d11.loanProgram=d1.loanProgram
   AND    d11.WACLow=d1.WACLow
   AND    d11.servicerNumber=d1.servicerNumber
   AND    d11.rptType=@v_type
   AND    DATEDIFF(MONTH, aft.dbo.fn_yearMonthDayToDate(d11.rptYear, d11.rptMonth, 18), 
                          aft.dbo.fn_yearMonthDayToDate(d10.rptYear, d10.rptMonth, 18))=1  
   AND    d10.adjYearMonth-d11.adjYearMonth IN (0, 1, 89)
   AND    d12.origYear=d1.origYear
   AND    d12.origTerm=d1.origTerm
   AND    d12.loanProgram=d1.loanProgram
   AND    d12.WACLow=d1.WACLow
   AND    d12.servicerNumber=d1.servicerNumber
   AND    d12.rptType=@v_type
   AND    DATEDIFF(MONTH, aft.dbo.fn_yearMonthDayToDate(d12.rptYear, d12.rptMonth, 18), 
                          aft.dbo.fn_yearMonthDayToDate(d11.rptYear, d11.rptMonth, 18))=1  
   AND    d11.adjYearMonth-d12.adjYearMonth IN (0, 1, 89)

   INSERT INTO etlLog (process, timeStamp,  message)
   VALUES ('setCPR', getdate(), 'Ended')
   PRINT 'setCPR: ended'

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

