--------------------------------------------------------------------------
-- Procedure: setCPRlife
-- Usage: setCPRlife @v_type, @n_year, @n_month
-- Parameters: 
--    v_type: indicating the report is for Chicago (C) or System (S)
--    n_year, n_month: indicating the Year, month regarded as current.
-- Comment: Called by collectData(), calculates the CPRlife for the current period.
--------------------------------------------------------------------------

ALTER PROCEDURE setCPRlife (@v_type CHAR, @n_year SMALLINT, @n_month SMALLINT) AS
DECLARE @n_adjYearMonth INT
   SET @n_adjYearMonth=100*@n_Year + @n_month
   
   UPDATE d1 
   SET    CPRlife=1.0-(1-ISNULL(d2.CPRlife,0))*(1-d1.SMM)
   FROM   PoolData AS d1 LEFT OUTER JOIN PoolData AS d2 ON 
      d1.origYear=d2.origYear AND
      d1.origTerm=d2.origTerm AND
      d1.loanProgram=d2.loanProgram AND
      d1.servicerNumber=d2.servicerNumber AND
      d1.WACLow=d2.WACLow AND
      d1.rptType=d2.rptType AND
      DATEDIFF(MONTH, aft.dbo.fn_yearMonthDayToDate(D2.rptYear, d2.rptMonth, 18), 
                      aft.dbo.fn_yearMonthDayToDate(d1.rptYear, d1.rptMonth, 18))=1 AND 
      d1.adjYearMonth-d2.adjYearMonth IN (0, 1, 89)
   WHERE  d1.rptYear=@n_Year
   AND    d1.rptMonth=@n_Month  
   AND    d1.rptType=@v_type
