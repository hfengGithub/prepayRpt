---------------------------------------------------------------------------
-- Procedure : loadAll
-- Usage     : loadAll 'A', 'Y', @n_year, @n_month
-- Parameter : 
--    v_type: indicating the report is for Chicago (C), System (S) or all (A)
--    v_agencyData: indicating whether loading agency data or not (Y/N, N=default) 
--    n_year, n_month: indicating the Year, month regarded as current (default=current)
-- Comment   : It is the controlling procedure for generating the monthly reports; Calling collectData() 
--             and  calcScore(). It could be run in reports database manually or by a scheduled job.
---------------------------------------------------------------------------

ALTER PROC loadAll
   @v_type VARCHAR(1)=NULL, 
   @v_agencyData VARCHAR(1)='N',
   @n_year SMALLINT=NULL, 
   @n_month SMALLINT=NULL 
AS
DECLARE @n_status INT 
   PRINT 'loadAll '+@v_type+' '+@v_agencyData+' '+CAST(@n_year AS VARCHAR)+' '+
      CAST(@n_month AS VARCHAR)+' started at:'+CAST(getdate() AS VARCHAR)
   INSERT INTO etlLog (process, timeStamp,  message)
   VALUES ('loadAll', getdate(), 
      'Started with param: '+@v_type+', '+@v_agencyData+', '+CAST(@n_year AS VARCHAR)+', '+CAST(@n_month AS VARCHAR))

   IF (@n_year IS NULL)
      BEGIN
         SET @n_year=YEAR(getdate())
         SET @n_month=MONTH(getdate())
      END

   -- Load all types
   IF (@v_type IS NULL OR @v_type='A')
      BEGIN
         TRUNCATE TABLE servicer
         TRUNCATE TABLE servicerPool
         TRUNCATE TABLE poolData
         TRUNCATE TABLE monthlyReport
         
         INSERT INTO servicer
         SELECT *  
         FROM   fhlb.dbo.fhlbServicerLookup
         
         -- UPDATE servicer
         -- SET    servicerName=servicerName+'.'
         -- WHERE  servicerNumber IN (4178, 4455)
         
         INSERT INTO servicer VALUES(1000, 'MPF')
         INSERT INTO servicer VALUES(1001, 'FHLMC')
         INSERT INTO servicer VALUES(1002, 'FNMA')
         INSERT INTO servicer VALUES(1003, 'All Others')
         INSERT INTO servicer VALUES(1004, 'GNMA II')
         INSERT INTO servicer VALUES(1100, 'Unknown')
         
         EXEC @n_status=collectData 'C', 'Y', @n_year, @n_month
         IF (@@ERROR<>0 OR @n_status<>0) RETURN 1
         EXEC @n_status=collectData 'S', 'N', @n_year, @n_month
         IF (@@ERROR<>0 OR @n_status<>0) RETURN 1
      END
   ELSE
      BEGIN
         -- collect Chicago participation or system data only
         DELETE servicerPool WHERE rptType=@v_type
         DELETE poolData WHERE rptType=@v_type
         DELETE monthlyReport WHERE rptType=@v_type
         EXEC collectData @v_type, @v_agencyData, @n_year, @n_month
      END

   EXEC calcScore 'A', @n_year, @n_month
   
   INSERT INTO etlLog (process, timeStamp,  message)
   VALUES ('loadAll', getdate(), 'Ended')

   PRINT 'loadAll '+@v_type+' '+@v_agencyData+' '+CAST(@n_year AS VARCHAR)+' '+
      CAST(@n_month AS VARCHAR)+' ended at:'+CAST(getdate() AS VARCHAR)
