if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[agencyDataHist]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[agencyDataHist]
GO

CREATE TABLE [dbo].[agencyDataHist] (
	[agency] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[servicerNumber] [int] NULL ,
	[ServicerName] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[OrigTerm] [smallint] NOT NULL ,
	[LoanProgram] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[GrossCoupon] [real] NOT NULL ,
	[GrossCouponInt] [float] NOT NULL ,
	[NetCoupon] [real] NULL ,
	[OrigYear] [smallint] NOT NULL ,
	[FactorCalc] [real] NULL ,
	[OrigBal] [float] NULL ,
	[CurrentBal] [float] NULL ,
	[WALA] [smallint] NULL ,
	[CPR1Month] [real] NULL ,
	[CPR3Month] [real] NULL ,
	[CPR6Month] [real] NULL ,
	[CPR12Month] [real] NULL ,
	[CPRLife] [real] NULL ,
	[Source] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Type] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[rptYearMonth] [int] NULL 
) ON [PRIMARY]
GO

