------------------------------------------------------------------------------
-- PROCEDURE :rankServicer
-- Usage: rankServicer @v_type, @n_year, @n_month
-- Parameters: 
--   v_type: indicating the report is for Chicago (C) or System (S)
--   n_year, n_month: indicating the Year, month regarded as current.
-- Comment: Called by collectData(), for each period prior to the current one, determines the 
--          top 20 PFIs and AllOthers by their balance of the period, write their ranks into 
--          servicerPool.
------------------------------------------------------------------------------
  
ALTER   PROCEDURE rankServicer (@v_type CHAR, @n_year INT, @n_month INT) AS
DECLARE @n_servicerNumber INT, @n_curBal float
DECLARE @n_rankOther SMALLINT, @n_rank SMALLINT, @n_top SMALLINT
   INSERT INTO etlLog (process, timeStamp,  message)
   VALUES ('rankServicer', getdate(), 'Started')

   SET @n_rankOther=(SELECT refValue FROM rptReference WHERE refCode='RANKOTHER')
   SET @n_rank=(SELECT refValue FROM rptReference WHERE refCode='RANKFIRST')
   SET @n_top=(SELECT refValue FROM rptReference WHERE refCode='RANKLAST')

   IF @v_type='C'
      DECLARE c_servicer CURSOR FOR
         SELECT M.servicerNumber, SUM(h.currentBal*p.chicagoParticipation) bal
         FROM   aft.dbo.aftMaster m, aft.dbo.aftHistory h, 
                aft_work.dbo.chicagoParticipation_loanLevel p
         WHERE  m.agency='FHLB'
         AND    h.histMonth=@n_month
         AND    h.histYear=@n_year
         AND    h.loanIDNumber=m.loanIdNUmber
         AND    p.loanNumber=m.loanIDnumber
         GROUP BY m.servicerNumber
         ORDER BY bal DESC
   ELSE
      DECLARE c_servicer CURSOR FOR
         SELECT M.servicerNumber, SUM(h.currentBal) bal
         FROM   aft.dbo.aftMaster m, aft.dbo.aftHistory h
         WHERE  m.agency='FHLB'
         AND    h.histMonth=@n_month
         AND    h.histYear=@n_year
         AND    h.loanIDNumber=m.loanIdNUmber
         GROUP BY m.servicerNumber
         ORDER BY bal DESC
      
   INSERT INTO servicerPool (rptYear, rptMonth, poolRank, servicerNumber, rptType) 
   SELECT @n_year, @n_month, r.refValue, s.servicerNumber, @v_type
   FROM   servicer s, rptReference r
   WHERE  servicerName='MPF'
   AND    r.refCode='RANKMPF'
   
   INSERT INTO servicerPool (rptYear, rptMonth, poolRank, servicerNumber, rptType) 
   SELECT @n_year, @n_month, @n_rankOther, s.servicerNumber, @v_type
   FROM   servicer s
   WHERE  s.servicerName='All Others'

   OPEN c_servicer
   FETCH NEXT FROM c_servicer INTO @n_servicerNumber, @n_curBal
   
   WHILE (@@FETCH_STATUS <> -1)
   BEGIN
      INSERT INTO servicerPool (
         rptYear,
         rptMonth,
         poolRank,
         servicerNumber,
         curBal, 
         rptType) 
      VALUES (@n_year, @n_month, @n_rank, @n_servicerNumber, @n_curBal, @v_type)

      IF ( @n_rank<=@n_top ) 
         IF ( @n_rank<@n_top ) SET @n_rank = @n_rank + 1
         ELSE SET @n_rank = @n_rankOther 
      
      FETCH NEXT FROM c_servicer INTO @n_servicerNumber, @n_curBal
   END
   CLOSE c_servicer
   DEALLOCATE c_servicer

   INSERT INTO etlLog (process, timeStamp,  message)
   VALUES ('rankServicer', getdate(), 'Ended')

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

